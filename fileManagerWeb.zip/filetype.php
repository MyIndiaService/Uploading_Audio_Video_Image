<?php
$resupd="";
$res="";
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<script>
function showUser(str)
{
	if (str=="")
	  {
	  document.getElementById("txtHint").innerHTML="";
	  return;
	  } 
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
		document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
		}
	  }
xmlhttp.open("GET","ajaxfiletype.php?q="+str,true);
xmlhttp.send();
}
</script>
<?php
include("connectiondb.php");
 
$createddate = date("Y-m-d");

//if($_SESSION[setid] == $_POST[setid])
{
			
	if(isset($_POST["submit"]))
	{
		if($_FILES["file"]["name"] == "")
		{
			$filename = $_POST[hiddenfile];
		}
		else
		{
			$filename = rand().$_FILES["file"]["name"];	
			move_uploaded_file($_FILES["file"]["tmp_name"],"files/" . $filename);
		}	

$sqlft = "SELECT * FROM filetypes where file_extension ='$_POST[fileextension]'";
$selft = mysqli_query($dbconn, $sqlft);
$msft = mysqli_fetch_array($selft);
		
			if(mysqli_num_rows($selft) == 1)
			{					
				$sqlupdquery = "UPDATE filetypes set file_type='$_POST[filetype]',file_path='$filename',status='Enabled' where file_extension ='$_POST[fileextension]'";
				$selque = mysqli_query($dbconn, $sqlupdquery);
				if(!$selque)
					{
						$res =  "<br>Problem in SQL insert query". mysqli_error();
						$resi=1;
					}
					else
					{
						$res =  "<br><font color='green'><h1>File type updated successfully...</h1><br>
						</font>";
						$resi=1;
					}
			}
			else
			{
			
					$sqlquery = "INSERT INTO filetypes (file_extension,file_type,file_path,status) VALUES ('$_POST[fileextension]', '$_POST[filetype]','$filename','Enabled')";
					$insquery = mysqli_query($dbconn, $sqlquery);
					if(!$insquery)
					{
						$res =  "<br>Problem in SQL insert query". mysqli_error();
					}
					else
					{
						$res =  "<br><font color='green'><h1>File type  inserted successfully...</h1><br></font>";
					}
			}
	}
}

if(isset($_GET['brid']))
{
	$sqlquery = "DELETE FROM branches where branch_id='$_GET[brid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Branch record Deleted successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}



$sqlselquery = "SELECT * FROM branches where branch_id='$_GET[editid]'";
$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);


$_SESSION['setid'] = rand();

?>

    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">    
         	
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>File type</h1>
                      
                        
                    </div>
                    <div class="templatemo_post_mid">
 <?php
						if(strlen($resupd) == 149)
						{
							echo "<p align='center'>".$resupd."</p>";
						}
?>

<form action="" method="post" enctype="multipart/form-data" name="formfiletype" onsubmit="return validation()">
<div id="txtHint">
<input type="hidden" name="setid" value="<?php echo $_SESSION['setid']; ?>" >
<table width="467" align="center" border="0"  >
 <tr>
 <td colspan="2"><?php echo $res; ?></td>
 </tr>
  <tr>
    <td height="38"><strong>File Extension</strong></td>
    <td><select name="fileextension" onchange="showUser(this.value)">
      <option value="Select">Select</option>
      <option value="image/jpg">image/jpg - jpg jpeg jpe</option>
      <option value="image/png">image/png - png</option>
      <option value="image/gif">image/gif - gif</option>
      <option value="image/bmp">image/bmp - bmp</option>
      <option value="application/msword">imagemsword/msword - doc,docx</option>
      <option value="application/vnd.ms-excel">application/vnd.ms-excel - xls,xlt,xlm,xld,xla,xlc,xlw,xll</option>
      <option value="application/vnd.ms-powerpoint">application/vnd.ms-powerpoint - ppt,pps</option>
      <option value="application/rtf">application/rtf - rtf</option>
      <option value="application/pdf">application/pdf - pdf</option>
      <option value="text/html">text/html - html,htm,php</option>
      <option value="text/plain">text/plain - txt</option>
      <option value="video/mpeg">video/mpeg - mpeg, mpg, mpe</option>
      <option value="audio/mpeg3">audio/mpeg3 - mp3</option>
      <option value="audio/wav">audio/wav - wav</option>            
      <option value="Unknown">Unknown</option>
    </select></td>
  </tr>
<tr>
  <td width="106" height="42"><strong>File type</strong></td>
  <td width="306"><input name="filetype" type="text" id="filetype" size="45" /></td>
</tr>
<tr>
<td height="37"><strong>File Icon</strong></td>
<td><input type="file" name="file" id="file" /></td></tr>
<tr><td height="32" colspan="2" align="center"><input type="submit" name="submit" align="middle"></td></tr>

</table>
</div>
</form>
 <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View File Types</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                    <table width="548" border="1">
  <tr>
    <th width="150" scope="col">&nbsp;Icon</th>  
    <th width="143" scope="col">&nbsp;File Extension</th>
    <th width="233" scope="col">&nbsp;File Type</th>
  </tr>
  <?php
  $sql = "select * from filetypes";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <tr>
		<td><center><img src='files/$rs[file_path]' width='100' height='100'></center></td>	  
		<td>&nbsp;$rs[file_extension]</td>
		<td>&nbsp;$rs[file_type]</td>
	  </tr>";
	}
  ?>
</table>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formfiletype.fileextension.value=="")
	{
		alert("Enter File Extension");
		document.formfiletype.fileextension.focus();
		return false;
	}
	else if(document.formfiletype.filetype.value=="")
	{
		alert("Please enter file type");
		document.formfiletype.filetype.focus();
		return false;
	}	
	else
	{
		return true;
	}
}
</script> 