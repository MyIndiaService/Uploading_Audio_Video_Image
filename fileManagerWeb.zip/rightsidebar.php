<?php
//session_start(); // Developed by www.freestudentprojects.com
?>
<div id="templatemo_right_section">
            	
                <div class="templatemo_section_box">
                	<div class="templatemo_section_box_top">
                
                    	 <?php
                    if(isset($_SESSION["admin_id"]))
					{
					?>
                           <h1>Menu</h1> 
                        <?php
					}
					?>
                    </div>
					<div class="templatemo_section_box_mid">
            
                    <?php
                   	if(isset($_SESSION["admin_id"]))
					{
					?>
                   
<table width="200" border="1">
  <tr>
    <td align="center">&nbsp;<a href="adminmyaccount.php"><img src="images/icons/myaccount.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>My Account</strong>
    </a></td>
    <td align="center">&nbsp;<a href="adminprofile.php"><img  src="images/icons/profileicon.png" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Profile</strong></a></td>
  </tr>
   <tr>
    <td align="center">&nbsp;<a href="changepassword.php"><img  src="images/icons/cpassword.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Change password</strong></a></td>
    <td align="center">&nbsp;<a href="Branch.php"><img  src="images/icons/branches.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Branches</strong>
    </a></td>
  </tr>
    <tr>
    <td align="center">&nbsp;<a href="desig.php"><img  src="images/icons/DESIGNATION.PNG" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Designation</strong></a></td>
    <td align="center">&nbsp;<a href="filetype.php"><img  src="images/icons/filetype.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>File types</strong></a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;<a href="admin.php"><img src="images/icons/admin.jpg" width="124" height="125" /><br />
      <strong>Admin Accounts</strong></a></td>
    <td align="center">&nbsp;<a href="employee.php"><img  src="images/icons/employees.png" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Employees</strong></a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;<a href="files.php"><img  src="images/icons/files.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Files</strong></a></td>
    <td align="center">&nbsp;<a href="Notification.php"><img  src="images/icons/NOTIFICATION.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Notification</strong></a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;<a href="filemanager.php"><img  src="images/icons/SHARE.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>File Manager</strong></a></td>
    <td align="center">&nbsp;<a href="logout.php"><img  src="images/icons/LOGOUT.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Logout</strong></a></td>
  </tr>
</table>
					<?php
					}
					else if(isset($_SESSION["emp_id"]))
					{
					?>
<table width="200" border="1">
  <tr>
    <td align="center">&nbsp;<a href="empmyaccount.php"><img src="images/icons/myaccount.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>My Account</strong>
    </a></td>
    <td align="center">&nbsp;<a href="editemployeeprofile.php"><img  src="images/icons/profileicon.png" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Profile</strong></a></td>
  </tr>
   <tr>
     <td align="center">&nbsp;<a href="files.php"><img  src="images/icons/files.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
         <strong>Files</strong></a></td>
     <td align="center"><a href="filemanager.php"><img  src="images/icons/SHARE.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
         <strong>File Manager</strong></a></td>
   </tr>
    <tr>
      <td align="center">&nbsp;<a href="Notification.php"><img  src="images/icons/NOTIFICATION.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
          <strong>Notification</strong></a></td>
      <td align="center">&nbsp;</td>
    </tr>
  <tr>
    <td align="center"><a href="empchangepassword.php"><img  src="images/icons/cpassword.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
        <strong>Change password</strong></a>&nbsp;</td>
    <td align="center">&nbsp;<a href="logout.php"><img  src="images/icons/LOGOUT.jpg" alt="125x125 Ad Banner" width="125" height="125" /><br />
      <strong>Logout</strong></a></td>
  </tr>
</table>
					<?php						
					}
					else
					{
					?>
                    <table width="200" border="0">
  <tr>
    <td colspan="2" align="center"><p><img src="images/24X7-Bank.jpg" width="249" height="256" /><br />
      <img src="images/24X7bank promo.png" width="247" height="283" />    </p></td>
  </tr>
   </table>
                    <?php    
					}
					?>
 <div class="clear">&nbsp;</div>
					</div>
                  <div class="templatemo_section_box_bottom"></div>
                </div><!-- end of section box --><!-- end of section box --><!-- end of section box -->
                
            
            </div><!-- end of right Section -->         