<?php
//session_start(); // Developed by www.freestudentprojects.com

$pagename =  basename($_SERVER['PHP_SELF']); /* Returns The Current PHP File Name */
function returnMIMEType($filename)
    {
        preg_match("|\.([a-z0-9]{2,4})$|i", $filename, $fileSuffix);

        switch(strtolower($fileSuffix[1]))
        {
            case "js" :
                return "application/x-javascript";

            case "json" :
                return "application/json";

            case "jpg" :
            case "jpeg" :
            case "jpe" :
                return "image/jpg";
				
            case "png" :
            case "gif" :
            case "bmp" :
            case "tiff" :
                return "image/".strtolower($fileSuffix[1]);

            case "css" :
                return "text/css";

            case "xml" :
                return "application/xml";
            case "doc" :
            case "docx" :
                return "application/msword";
            case "xls" :
            case "xlt" :
            case "xlm" :
            case "xld" :
            case "xla" :
            case "xlc" :
            case "xlw" :
            case "xll" :
                return "application/vnd.ms-excel";

            case "ppt" :
            case "pps" :
                return "application/vnd.ms-powerpoint";

            case "rtf" :
                return "application/rtf";

            case "pdf" :
                return "application/pdf";

            case "html" :
            case "htm" :
            case "php" :
                return "text/html";

            case "txt" :
                return "text/plain";

            case "mpeg" :
            case "mpg" :
            case "mpe" :
                return "video/mpeg";
				
            case "mp3" :
                return "audio/mpeg3";

            case "wav" :
                return "audio/wav";

            case "aiff" :
            case "aif" :
                return "audio/aiff";
            case "avi" :
                return "video/msvideo";

            case "wmv" :
                return "video/x-ms-wmv";

            case "mov" :
                return "video/quicktime";

            case "zip" :
                return "application/zip";

            case "tar" :
                return "application/x-tar";

            case "swf" :
                return "application/x-shockwave-flash";

            default :
            if(function_exists("mime_content_type"))
            {
                //$fileSuffix = mime_content_type($filename);
            }

            return "unknown/" . trim($fileSuffix[0], ".");
        }
    }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Web File Manager</title>

<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

</head>

<body>
	<div id="templatemo_background_section_top">
    
    	<div class="templatemo_container">
		
       	  <div id="templatemo_header">
			<div id="templatemo_logo_section">            
		        	<h1>Web File Manager</h1>            
					<h2>Developed by <a href="http://www.myindiaservice.com">Freelance developer</a> </h2>
				</div>
       	  </div>
       	  <!-- end of headder -->

        		        <?php
						if(isset($_SESSION["logintype"]) && $_SESSION["logintype"] == "Employee")
						{
						?>
    		<div id="templatemo_menu_panel">
    			<div id="templatemo_menu_section">
                        <ul>
                        	<li><a href="index.php" class="current">Home</a></li>
                            <li><a href="editemployeeprofile.php">Profile</a>
                            <li><a href="filemanager.php?shared=true">Shared Files</a></li> 
                            <li><a href="viewnotification.php">Received Files</a></li>   
                            <li><a href="Notification.php">Notification</a></li>  
                            <li><a href="logout.php">Logout</a></li>
                         </ul> 
				</div>  
		    </div> <!-- end of menu -->           
                        <?php
						}
						
						if(isset($_SOSSION['logintype']) && $_SESSION["logintype"] == "Admin")
						{
						?>
    		<div id="templatemo_menu_panel">
    			<div id="templatemo_menu_section">
                        <ul>
                        	<li><a href="index.php"  class="current">Home</a></li>
                            <li><a href="adminprofile.php">Profile</a>
                            <li><a href="filemanager.php?shared=true">Shared Files</a></li> 
                            <li><a href="viewnotification.php">Received Files</a></li>   
                            <li><a href="Notification.php">Notification</a></li>  
                            <li><a href="logout.php">Logout</a> </li> 
                        </ul> 
				</div>
		    </div> <!-- end of menu -->
                        <?php
						}
						?>


            
		</div><!-- end of container-->
        
	</div><!-- end of templatemo_background_section_top-->
<?php
if($pagename == "index.php")
{
?>    
    <center><?php include("slider.php"); ?></center>
<?php
}
?>    