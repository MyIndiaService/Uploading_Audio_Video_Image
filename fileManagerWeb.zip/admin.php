<?php
$resi="";
$mssql="";
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<?php
include("connectiondb.php");
 
$createddate = date("Y-m-d");

if(isset($_POST['setid']) && $_SESSION['setid'] == $_POST['setid'])
{
	if(isset($_POST["submit"]))
	{
		if(isset($_GET['editid']))
		{
			$sqlupdquery = "UPDATE administrator set admin_type='$_POST[adtype]',admin_name='$_POST[adname]',login_id='$_POST[log]',password='$_POST[pass]',email_id='$_POST[email]',
			created_date='$createddate',status='$_POST[status]' where  admin_id='$_GET[editid]'";
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(!$selque)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
			}
			else
			{
				$res =  "<br><font color='green'><h1>Admin record updated successfully...</h1><br>
				<h2><a href='admin.php?editid=$_GET[editid]'>Click here to Edit..</a></h2>
				</font>";
				$resi=2;
			}
		}
		else if(isset($_GET['updatemyaccount']))
		{
			$sqlupdquery = "UPDATE administrator set admin_type='$_POST[adtype]',admin_name='$_POST[adname]',login_id='$_POST[log]',password='$_POST[pass]',email_id='$_POST[email]',
			created_date='$createddate',status='$_POST[status]' where  admin_id='$_GET[editid]'";
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(!$selque)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
			}
			else
			{
				$res =  "<br><font color='green'><h1>Admin record updated successfully...</h1><br>
				<h2><a href='admin.php?editid=$_GET[editid]'>Click here to Edit..</a></h2>
				</font>";
				$resi=2;
			}
		}
		else
		{
			$sqlquery = "INSERT INTO administrator (admin_type,admin_name,login_id,password,email_id,created_date,status) VALUES ('$_POST[adtype]', '$_POST[adname]','$_POST[log]','$_POST[pass]','$_POST[email]','$createddate','$_POST[status]')";
			$insquery = mysqli_query($dbconn, $sqlquery);
			if(!$insquery)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
			}
			else
			{
				$res =  "<br><font color='green'><h1>Record inserted successfully...</h1><br>
				<h2><a href='admin.php'>Click here to add more..</a></h2>
				</font>";
				$resi=1;
			}
		}
		
	}
}

if(isset($_GET['adid']))
{
	$sqlselquery = "SELECT * FROM administrator where admin_id='$_GET[admin_id]'";
	$sqlquery = "DELETE FROM administrator where admin_id='$_GET[adid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Administrator record Deleted successfully...</h1><br>
			<h2><a href='admin.php'>Click here to add more..</a></h2>
			</font>";
		}
}

$_SESSION['setid'] = rand();


if(isset($_GET['updatemyaccount']))
{
	$sqlselquery = "SELECT * FROM administrator where admin_id='$_GET[updatemyaccount]'";
	$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);	
}
else if(isset($_GET['editid']))
{
	$sqlselquery = "SELECT * FROM administrator where admin_id='$_GET[editid]'";
	$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);
}

?>

    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Admin Details</h1>
                    </div>
                    <div class="templatemo_post_mid">                 

<form method="post" action="" name="formadmin" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION['setid']; ?>" >
<table width="372" height="302" align="center" >
<?php
if($resi == 1)
{
?>
	<tr>
  		<td height="43" colspan="2" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
else if($resi == 2)
{
?>
	<tr>
  		<td colspan="2" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
else
{
?>
	<tr>
	<td width="127" align=""><strong><label> Admin Type</label></strong></td>
	<td width="233">
		<?php
        $arr = array("Select","Super Admin","Admin");
        ?>
            <select name="adtype">
            <?php
            foreach($arr as $value)
            {
                if($value == $mssql[admin_type])
                {
                echo "<option value='$value' selected>$value</option>";
                }
                else
                {
                echo "<option value='$value'>$value</option>";
                }
            }
            ?>
            </select>
    </td>
	</tr>
<tr>
<td><strong> Admin Full Name</strong></td>
<td><input type="text" name="adname" size="30" value="<?php echo $mssql[admin_name];?>"></td></tr>
<tr>
  <td><strong>Admin Login ID</strong></td>
<td><input type="text" name="log" size="30" value="<?php echo $mssql[login_id];?>"></td></tr>
<tr>
  <td><strong>New Password</strong></td>
<td><input type="password" name="pass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>
<tr>
  <td><strong>Confirm Password</strong></td>
<td><input type="password" name="cpass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>
<tr>
  <td><strong>Email Id</strong></td>
<td><input type="text" name="email" size="30" value="<?php echo $mssql['email_id'];?>"></td></tr>
<tr>
  <td><strong>Account Status</strong></td>
<td>
<?php
$arr = array("Select","Enabled","Disabled");
?>
<select name="status">
<?php
foreach($arr as $value)
{
	if($value == $mssql[status])
	{
	echo "<option value='$value' selected>$value</option>";
	}
	else
	{
	echo "<option value='$value'>$value</option>";
	}
}
?>
</select>
</td></tr>
<tr><td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit"></td></tr>
<?php
}
?>
</table>
</form>
                
                      <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                

				<?php
				if($_GET[updatemyaccount] == 0)
				{
				?> 

                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View Administrator record</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                    <table width="548" border="1">
  <tr>
    <th width="114" scope="col">&nbsp;Admin Type</th>
    <th width="181" scope="col">&nbsp;Admin Details</th>
    <th width="165" scope="col">History&nbsp;Details</th>
    <th width="60" scope="col">&nbsp;Status</th>
  </tr>
  <?php
  $sql = "select * from administrator";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <tr>
		<td>&nbsp;$rs[admin_type]</td>
		<td>&nbsp;Name : $rs[admin_name] <br>
		    &nbsp;Email ID: $rs[email_id] <br>
			&nbsp;Login ID: $rs[login_id]
		 </td>
		<td>&nbsp;Created date: $rs[created_date] <br>
		    &nbsp;Last login: <br>$rs[last_login] 
		</td>
		<td align='center'>&nbsp;$rs[status]<br>";
		
		echo "<a href='admin.php?editid=$rs[admin_id]'>Edit</a>";
		
		if($rs[admin_type]!="Super Admin")
		{
		echo "<br><a href='Admin.php?adid=$rs[admin_id]' onclick='return ConfirmDelete()'>Delete</a>";
		}
		
		echo "</tr>";
		
	}
	
  ?>
</table>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div>
              
				<?php
				}
				?>               
              <!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formadmin.adtype.value=="Select")
	{
		alert("Select Admin Type.....!!!");
		return false;
	}
	else if(document.formadmin.adname.value=="")
	{
		alert("Enter Admin Name....!!!");
		return false;
	}
	else if(document.formadmin.adname.value.length <2)
	{
		alert("Minum two characters required for Admin Name")
        document.formadmin.adname.focus();
		return false;
	}
	else if(document.formadmin.adname.value.length >20)
	{
		alert("Admin Name should not be exceed more than 20 characters")
        document.formadmin.adname.focus();
		return false;
	}
	else if(document.formadmin.log.value=="")
	{
		alert("Enter Login ID...!!!");
		return false;
	}
	
		else if(document.formadmin.log.value.length <6)
	{
		alert("Minum 6 characters required for Admin Login ID")
        document.formadmin.log.focus();
		return false;
	}
	else if(document.formadmin.log.value.length >25)
	{
		alert("Admin Name should not be exceed more than 20 characters")
        document.formadmin.log.focus();
		return false;
	}
	else if(document.formadmin.pass.value=="")
	{
		alert("Enter Password...!!!");
		return false;
	}
	
		else if(document.formadmin.pass.value.length <6)
	{
		alert("Minum 6 characters required for Password")
        document.formadmin.pass.focus();
		return false;
	}
	else if(document.formadmin.pass.value.length >12)
	{
		alert("Password should not be exceed more than 12 characters")
        document.formadmin.pass.focus();
		return false;
	}
		else if(document.formadmin.cpass.value.length <6)
	{
		alert("Minum 6 characters required for Confirm Password")
        document.formadmin.cpass.focus();
		return false;
	}
	else if(document.formadmin.cpass.value.length >12)
	{
		alert("Confirm Password should not be exceed more than 12 characters")
        document.formadmin.cpass.focus();
		return false;
	}
	else if(document.formadmin.cpass.value=="")
	{
		alert("Please Confirm your Password...!!!");
		return false;
	}
	else if(document.formadmin.pass.value != document.formadmin.cpass.value)
	{
		alert("Password and confirm password not matching..!!!");
		document.formadmin.cpass.focus();
		return false;
	}
	else if(document.formadmin.email.value=="")
	{
		alert("Please enter your Email ID...!!!");
		return false;
	}
		else if(document.formadmin.email.value.length <6)
	{
		alert("Minum 6 characters required for Email")
        document.formadmin.email.focus();
		return false;
	}
	else if(document.formadmin.email.value.length >25)
	{
		alert("Email should not be exceed more than 25 characters")
        document.formadmin.email.focus();
		return false;
	}
	else if(document.formadmin.status.value=="")
	{
		alert("Select status...!!!");
		return false;
	}
	
	else
	{
		return true;
	}
}
</script>