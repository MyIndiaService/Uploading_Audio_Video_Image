<?php
session_start(); // Developed by www.freestudentprojects.com
if(!isset($_SESSION["emp_id"]))
{
	header("Location: index.php");
}
include("header.php");
include("connectiondb.php");
$sqlbrqueryemp = "SELECT * FROM employees where emp_id='$_SESSION[emp_id]'";
$selqueemp = mysqli_query($dbconn, $sqlbrqueryemp);
$rsrecemp = mysqli_fetch_array($selqueemp);
?>
    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            <div class="templatemo_post">
                      
                
                   			<div id="templatemo_search_box">
                              <form action="filemanager.php" method="get">
                               		  <h1> &nbsp; <font color="#FFFFFF">Search files</font> <input name="search" type="text" id="textfield" value=""/>
                                    <input type="submit" name="Submit" value="Search" alt="Submit" id="button" title="Submit" /></h1> 
                                </form>    
                			</div>                  
				</div>
            	
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Last login</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	                        
                        <p>Last login Date and Time: <?php echo $_SESSION[last_login]; ?></p>
                        
                        <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom"></div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Profile details</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                        <p><img alt="Blog" src="<?php 
						if($rsrecemp[profilepic] != "")
						{
						echo "files/".$rsrecemp[profilepic];
						}
						else
						{
						echo "images/employee.png";
						}
						?>"  width="200" height="200"/>
                        <strong>Name : </strong><?php echo $rsrecemp[emp_fname] . " " . $rsrecemp[emp_lname]; ?><br />
                        <strong>Login ID. : </strong><?php echo $rsrecemp[login_id]; ?><br />                        
                        <strong>Date of Join : </strong><?php echo $rsrecemp[doj]; ?><br />
                        <strong>Date of Birth : </strong><?php echo $rsrecemp[dob]; ?><br />
                        <strong>Email ID : </strong><?php echo $rsrecemp[email_id]; ?><br />
                        <strong>Contact No. : </strong><?php echo $rsrecemp[contact_no]; ?><br />
                        <strong>Gender. : </strong><?php echo $rsrecemp[gender]; ?><br />
<?php
$sqlbrqueryempb = "SELECT * FROM branches where branch_id='$rsrecemp[branch_id]'";
$selqueempb = mysqli_query($dbconn, $sqlbrqueryempb);
$rsrecempb = mysqli_fetch_array($selqueempb);
?><br />
                        <strong>Branch. : </strong><?php echo $rsrecempb[branch_name]; ?><br />
                        <?php echo $rsrecempb[address]; ?><br />
                        </p>


						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">

                    </div>
                    
				</div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>