-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2014 at 04:23 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webfilemanager`
--
CREATE DATABASE IF NOT EXISTS `webfilemanager` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `webfilemanager`;

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_type` varchar(15) NOT NULL,
  `admin_name` varchar(25) NOT NULL,
  `login_id` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `created_date` date NOT NULL,
  `last_login` datetime NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `email_id` (`email_id`),
  UNIQUE KEY `login_id` (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=115 ;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_id`, `admin_type`, `admin_name`, `login_id`, `password`, `email_id`, `created_date`, `last_login`, `status`) VALUES
(110, 'Admin', 'Jagath', 'Jagath', '012345', 'jagath@gmail.com', '2014-03-25', '2014-03-25 04:36:31', 'Enabled'),
(111, 'Super Admin', 'Jeevan Ananda', 'JeevanAnanda', 'jeevan1', 'jeevan@gmail.com', '2014-03-25', '2014-03-28 01:03:53', 'Enabled'),
(112, ' Admin', 'Janak', 'Janak', 'janak', 'janak@gmail.com', '2014-03-25', '2014-03-27 03:20:56', 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE IF NOT EXISTS `branches` (
  `branch_id` int(10) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(25) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=206 ;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `branch_name`, `address`, `city`, `state`, `country`, `contact_no`, `email_id`, `status`) VALUES
(200, 'Puttur', 'Dharmasthala Building,near Sanjiv Shetty building Puttur,D.K', 'Puttur', 'Karnataka', 'India', '9876543210', 'Ka.200sb@gmail.com', 'Enabled'),
(201, 'Madikeri', '18th block, Putani nagar, Madikeri', 'Madikeri', 'Karnataka', 'India', '9874623414', 'Ka.201sb@gmail.com', 'Enabled'),
(202, 'Manipal', 'Manipal Near jeevan Mansion house,Manipal', 'Manipal', 'Karnataka', 'India', '9874628414', 'Ka.202sb@gmail.com', 'Enabled'),
(203, 'Sullia', '18th block, Shivaji nagar, Sullia', 'Sullia', 'Karnataka', 'India', '9874603414', 'Ka.203sb@gmail.com', 'Enabled'),
(204, 'Mangalore', 'Hampankatta Mangalore,D.K', 'Mangalore', 'Karnataka', 'India', '9879543210', 'Ka.204sb@gmail.com', 'Enabled'),
(205, 'Kasargod', 'Main Building,Kasargod', 'Kasargod', 'Karnataka', 'India', '9876543210', 'ka.205sb@gmail.com', 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE IF NOT EXISTS `designation` (
  `desig_id` int(10) NOT NULL AUTO_INCREMENT,
  `desig_type` varchar(25) NOT NULL,
  `comments` text NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`desig_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`desig_id`, `desig_type`, `comments`, `status`) VALUES
(1, 'hmanager', 'test description', 'Enabled'),
(2, 'hmanager', '2 test desc', 'Enabled'),
(3, 'hmanager', '2 test desc', 'Enabled'),
(4, 'hmanager', '2 test desc', 'Enabled'),
(5, 'hmanager', '2 test desc', 'Enabled'),
(6, 'Manager', 'Manager', 'Enabled'),
(7, 'Asst Manager', 'Assistant Manager', 'Enabled'),
(8, 'Clerk', 'Clerks', 'Enabled'),
(9, 'Developer', 'Developer', 'Enabled'),
(10, 'Programmer', 'Programmer', 'Enabled'),
(11, 'BDM', 'Biz Develop Mnger', 'Enabled'),
(12, 'DM', 'Developement Manager', 'Enabled'),
(13, 'Project developer', 'Test description', 'Enabled'),
(14, 'hmanager', 'HR Manager', 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `emp_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) NOT NULL,
  `branch_id` int(10) NOT NULL,
  `desig_id` int(10) NOT NULL,
  `emp_fname` varchar(25) NOT NULL,
  `emp_lname` varchar(25) NOT NULL,
  `profilepic` varchar(50) NOT NULL,
  `doj` date NOT NULL,
  `dob` date NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `login_id` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `created_date` date NOT NULL,
  `last_login` datetime NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `admin_id`, `branch_id`, `desig_id`, `emp_fname`, `emp_lname`, `profilepic`, `doj`, `dob`, `email_id`, `contact_no`, `gender`, `login_id`, `password`, `created_date`, `last_login`, `status`) VALUES
(1, 111, 202, 3, 'james', 'peter', '24635admin.jpg', '2014-03-21', '1991-12-31', 'james@gmail.com', '987456320', 'Male', 'james', 'james', '2014-03-19', '2014-03-28 01:12:10', 'Enabled'),
(2, 112, 203, 7, 'Roopa', 'Rai', '24635admin.jpg', '2012-03-21', '1989-12-31', 'roopa@gmail.com', '987496324', 'female', 'Roopa', 'Roopa234', '2014-03-19', '2014-03-27 02:10:37', 'Enabled'),
(3, 110, 200, 4, 'Janak', 'Pai', '24635admin.jpg', '2012-03-21', '1990-12-31', 'janak@gmail.com', '987496320', 'Male', 'Janak', 'Pai1234', '2014-03-19', '2014-03-27 02:10:37', 'Enabled'),
(4, 111, 201, 6, 'Leela', 'Ravi', '24635admin.jpg', '2011-03-21', '1993-12-31', 'leela@gmail.com', '987896320', 'female', 'leela', 'leelaravi', '2014-03-19', '2014-03-27 02:10:37', 'Enabled'),
(5, 110, 204, 1, 'Ragu', 'Ram', '24635admin.jpg', '2011-03-21', '1991-12-31', 'ram@gmail.com', '989896320', 'male', 'Raguram', 'Raguram', '2014-03-19', '2014-03-27 02:10:37', 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `file_id` int(10) NOT NULL AUTO_INCREMENT,
  `ftype_id` int(10) NOT NULL,
  `sender_type` varchar(20) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `filedescription` text NOT NULL,
  `filepath` varchar(50) NOT NULL,
  `uploaded_at` datetime NOT NULL,
  `permission` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`file_id`, `ftype_id`, `sender_type`, `sender_id`, `filename`, `filedescription`, `filepath`, `uploaded_at`, `permission`, `status`) VALUES
(4, 0, 'Emloyee', 17, 'exe file', 'Exe executable file', '8794ChromeSetup.exe', '2014-03-25 00:00:00', 'All Employees', 'Enabled'),
(5, 0, 'Admin', 17, 'Powerpoint file', 'powerpoint', '2433BCA1010-Unit-01-PPT.pptx', '2014-03-22 00:00:00', 'All Employees', 'Enabled'),
(6, 0, 'Admin', 17, 'Document', 'Document', '7188libra_srs.doc', '2014-03-22 00:00:00', 'All Employees', 'Enabled'),
(7, 0, 'Emloyee', 17, 'PDF File', 'Pdf files', '12803Candidate_Report.pdf', '2014-03-22 00:00:00', 'All Employees', 'Enabled'),
(8, 0, 'Admin', 17, 'rar', 'rar', '14334isshcon2014regform.rar', '2014-03-22 00:00:00', 'All Employees', 'Enabled'),
(9, 0, 'Admin', 17, 'Excel file', '', '18037Hotel software time frame.xlsx', '2014-03-22 00:00:00', 'All Employees', 'Enabled'),
(10, 0, 'Admin', 17, 'Video file', 'Video file', '27524Facebook (2).mp4', '2014-03-25 00:00:00', 'Locked', 'Enabled'),
(11, 0, 'Admin', 17, 'PDF File', 'Pdf files', '12803Candidate_Report.pdf', '2014-03-25 00:00:00', 'All Employees', 'Enabled'),
(12, 0, 'Admin', 111, 'wordsbank', 'Bank Word Docs', '21991', '2014-03-28 00:00:00', 'Select', 'Select'),
(13, 0, 'Admin', 111, 'wordsbank', 'Bank Word Docs', '273357188libra_srs.doc', '2014-03-28 00:00:00', 'Select', 'Select'),
(14, 0, 'Admin', 111, 'Bank Docs', 'Bank Docs ', '168984591SOFTWARE REQUIREMENT ANALYSIS.docx', '2014-03-28 00:00:00', 'Select', 'Select');

-- --------------------------------------------------------

--
-- Table structure for table `filetypes`
--

CREATE TABLE IF NOT EXISTS `filetypes` (
  `ftype_id` int(10) NOT NULL AUTO_INCREMENT,
  `file_extension` varchar(25) NOT NULL,
  `file_type` varchar(25) NOT NULL,
  `file_path` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`ftype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `filetypes`
--

INSERT INTO `filetypes` (`ftype_id`, `file_extension`, `file_type`, `file_path`, `status`) VALUES
(1, 'image/jpg', 'JPG image', '20082jpg.jpg', 'Enabled'),
(2, 'application/pdf', 'Adobe PDF', '29466pdf.png', 'Enabled'),
(3, 'application/msword', 'MS Word', '28161msword.jpg', 'Enabled'),
(4, 'Unknown', 'Unknown', '21543unknown.jpg', 'Enabled'),
(5, 'Select', '', '', 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `notification_id` int(10) NOT NULL AUTO_INCREMENT,
  `emp_id1` int(10) NOT NULL,
  `emp_id2` int(10) NOT NULL,
  `subject` varchar(25) NOT NULL,
  `message` text NOT NULL,
  `mdate_time` datetime NOT NULL,
  `link` varchar(25) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
