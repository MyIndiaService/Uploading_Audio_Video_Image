<?php
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
include("connectiondb.php");

$dt = date("Y-m-d h:i:s");
if($_SESSION[setid] == $_POST[setid])
{
	if(isset($_POST[submit]))
	{
	$sqlquery = "INSERT INTO notification (emp_id1,emp_id2,subject,message,mdate_time,link,status) VALUES ( '$_SESSION[emp_id]','$_POST[empid]','$_POST[subname]','$_POST[txtarea]','$dt','$_POST[link]','Enabled')";
				$insquery = mysqli_query($dbconn, $sqlquery);
				if(!$insquery)
				{
					$res =  "<br>Problem in SQL insert query". mysqli_error();
					$resi=1;
				}
				else
				{
					$res =  "<br><font color='green'><h1>Notification sent successfully...</h1><br>
					<h2><a href='Notification.php'>Click here to send more notification..</a></h2>
					</font>";
					$resi=1;
				}
	}
}
$_SESSION[setid] = rand();
?>

 
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1><strong>&nbsp; Send Noitification</strong></h1>
                    </div>
                  <div class="templatemo_post_mid">    
<form method="post" action="" name="Formnotification" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION[setid]; ?>" />
<table width="470" height="297"  align="center">
<?php
if($resi == 1 )
{
?>
<tr>
  <td colspan="2" align="center">&nbsp;<?php echo $res; ?></td>
</tr>
<?php
}
else
{
?>
<tr>
  <td height="30">Send to</td>
  <td>
      <select name="empid" id="empid">
            <option value="">Select</option>
            <?php
			$sqlbrquery = "SELECT * FROM employees where status='Enabled' ";
			$selque = mysqli_query($dbconn, $sqlbrquery);
			while($rsrec = mysqli_fetch_array($selque))
			{
			echo "<option value='$rsrec[emp_id]'>$rsrec[login_id] - $rsrec[emp_fname] $rsrec[emp_lname]</option>";
			}
            ?>
      </select>
  </td>
</tr>
<td width="69" height="29"> Subject</td>
  <td width="258"><input type="text" name="subname" size="50"></td></tr>
<tr>
  <td colspan="2">Message
    :<br />    <textarea cols="50" rows="6" name="txtarea" ></textarea></td>
</tr>
  <td>Link</td>
  <td>
  	<select name="link" id="link">
        <option value="">Select</option>
        <?php
		$sqlbrquery = "SELECT * FROM files where status='Enabled'";
		$selque = mysqli_query($dbconn, $sqlbrquery);
		while($rsrec = mysqli_fetch_array($selque))
		{
		echo "<option value='$rsrec[file_id]'>$rsrec[filename] - $rsrec[filepath]</option>";
		}
		?>
	</select></td></tr>

<tr><td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit" align="middle"></td></tr>
<?php
}
?>
</table>
</form>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div>
                              
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  administrator";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1><a href="viewnotification.php">Click here to View Notification </a></h1>
                    </div>
         
              <!-- end of templatemo_post-->
                
            </div>
            
            
            <!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.Formnotification.empid.value=="")
	{
		alert("Select Employee ID")
		document.Formnotification.empid.focus();
		return false;
	}
	else if(document.Formnotification.subname.value=="")
	{
		alert("Enter Subject")
		document.Formnotification.subname.focus();
		return false;
	}
			else if(document.Formnotification.subname.value.length <6)
	{
		alert("Minum 6 characters required for file Subject")
        document.Formnotification.subname.focus();
		return false;
	}
	else if(document.Formnotification.subname.value.length >25)
	{
		alert("Subject should not be exceed more than 20 characters")
        document.Formnotification.subname.focus();
		return false;
	}
	else if(document.Formnotification.txtarea.value=="")
	{
		alert("Enter Message")
		document.Formnotification.txtarea.focus();
		return false;
	}
				else if(document.Formnotification.txtarea.value.length <6)
	{
		alert("Minum 6 characters required for file Subject")
        document.Formnotification.txtarea.focus();
		return false;
	}
	else if(document.Formnotification.txtarea.value.length >50)
	{
		alert("Message should not be exceed more than 50 characters")
        document.Formnotification.txtarea.focus();
		return false;
	}
	else if(document.Formnotification.link.value=="")
	{
		alert("Select Link")
		document.Formnotification.link.focus();
		return false;
	}	
	else
	{
		return true;
	}
}
</script>