<?php
$logeres="";
session_start(); // Developed by www.freestudentprojects.com
if(isset($_SESSION["emp_id"]))
{
	header("Location: empmyaccount.php");
}

if(isset($_SESSION["admin_id"]))
{
	header("Location: adminmyaccount.php");
}

include("connectiondb.php");
			$dt= date("Y-m-d h:i:s");

if(isset($_POST['emplogin']))
{
	$sql = "SELECT * FROM employees WHERE login_id='$_POST[log]' AND password='$_POST[pass]'";
	$qresult = mysqli_query($dbconn,$sql);
		if(mysqli_num_rows($qresult) == 1)
		{

			$rs = mysqli_fetch_array($qresult);
			$_SESSION["logintype"] = "Employee";
			$_SESSION["emp_id"] = $rs["emp_id"];
			$_SESSION["last_login"] = $rs["last_login"];
				$sql = "UPDATE employees SET last_login='$dt' WHERE login_id='$_POST[log]'";
				$qresult = mysqli_query($dbconn,$sql);
			header("Location: empmyaccount.php");
		}
		else
		{
			$logeres = "<font color='red'><h2>Failed to login</h2></font>";
		}
}

if(isset($_POST['btnadminlogin']))
{
	$sql = "SELECT * FROM administrator WHERE login_id='$_POST[loginid]' AND password='$_POST[pass]'";
	$qresult = mysqli_query($dbconn,$sql);
		if(mysqli_num_rows($qresult) == 1)
		{
			$rs = mysqli_fetch_array($qresult);
			$_SESSION["logintype"] = "Admin";			
			$_SESSION["admin_id"] = $rs["admin_id"];
			$_SESSION[last_login] = $rs["last_login"];
				$sql = "UPDATE administrator SET last_login='$dt' WHERE login_id='$_POST[loginid]'";
				$qresult = mysqli_query($dbconn,$sql);
			header("Location: adminmyaccount.php");
		}
		else
		{
			$logares = "<font color='red'><h2>Failed to login</h2></font>";
		}
}
include("header.php");
?>

    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            <div class="templatemo_post">
                      
                
                              
				</div>
            	
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Employee Login Panel</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    &nbsp; <table border="0" align="center">
                            <tr><td>
                             <?php
							echo $logeres;
							?>
                            </td></tr>
                            <tr>
                                       <td><img src="images/employee.png" width="211" height="187" /></td>
                            <td>
                            <form method="post" action="" name="formemplogin" onsubmit="return validation1()"> 
                            &nbsp;LOGIN ID<br><input type="text" name="log" size="30" /><br><br>
                            &nbsp;PASSWORD<br><input type="password" name="pass" size="30" /><br><br>
                            &nbsp;&nbsp;&nbsp;<input type="submit" value="Login" name="emplogin" class="fsLoginButton"/>
                            </form>
                                           </td>
                                </tr>
                                </table>
                    <br />		 <br />	
                        
                        <div class="clear"></div>
                        
                  </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Administrator Login Panel</h1>
                    </div>
                    <div class="templatemo_post_mid">
                            <table border="0" align="center">
                            <tr><td colspan="2">
                            <?php
							echo $logeres ;
							?>
                            </td></tr>
                            <tr>
                                  <td><img src="images/admin.png" width="211" height="187" /></td>
                            <td>
                            <form method="post" action="" name="formadminlogin" onsubmit="return validation2()"> 
                            &nbsp;LOGIN ID<br><input type="text" name="loginid" size="30" /><br><br>
                            &nbsp;PASSWORD<br><input type="password" name="pass" size="30" /><br><br>
                            &nbsp;&nbsp;&nbsp;<input type="submit" value="Login" name="btnadminlogin" class="fsLoginButton"/>
                            </form>
                            </td>
                      
                            </tr>
                            </table>
                            <br />		 <br />	
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>                    
				</div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
<?php
include("rightsidebar.php");
?>
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
<?php
include("footer.php");
?>
<script type="application/javascript">
function validation1()
{
	if(document.formemplogin.log.value=="")
	{
		alert("Login ID should not be empty..");
		return false;
	}
	else if(document.formemplogin.pass.value=="")
	{
		alert("password should not be empty..");
		return false;
	}
	else
	{
		return true;
	}
}
</script>
<script type="application/javascript">
function validation2()
{
	if(document.formadminlogin.loginid.value=="")
	{
		alert("Login ID should not be empty..");
		return false;
	}
	else if(document.formadminlogin.pass.value=="")
	{
		alert("password should not be empty..");
		return false;
	}
	else
	{
		return true;
	}
}
</script>

