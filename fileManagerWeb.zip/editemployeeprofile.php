<?php
session_start(); // Developed by www.freestudentprojects.com
include("connectiondb.php");
 

$createddate = date("Y-m-d");

if($_SESSION[setid] == $_POST[setid])
{
	if($_FILES["profilepic"]["name"] == "")
	{
		$filename = $_POST[hiddenprofilepic];
	}
	else
	{
		$filename = rand().$_FILES["profilepic"]["name"];	
		move_uploaded_file($_FILES["profilepic"]["tmp_name"],"files/" . $filename);
	}
	if(isset($_POST["submit"]))
	{
			$sqlupdquery = "UPDATE employees SET `emp_fname` = '$_POST[fname]', `emp_lname` = '$_POST[lname]', `profilepic` = '$filename', `email_id` = '$_POST[email]', `contact_no` = '$_POST[cno]', `login_id` = '$_POST[logid]' WHERE `employees`.`emp_id` = '$_SESSION[emp_id]'";
			
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(!$selque)
				{
					$res =  "<br>Problem in SQL insert query". mysqli_error();
				}
				else
				{
					$res =  "<br><font color='green'><h1>Branch record updated successfully...</h1><br>
					<h2><a href='Branch.php'>Click here to add more..</a></h2>
					</font>";
					$resi=1;
				}

	}
}
	
$_SESSION[setid] = rand();	

$sqlbrqueryemp = "SELECT * FROM employees where emp_id='$_SESSION[emp_id]'";
$selqueemp = mysqli_query($dbconn, $sqlbrqueryemp);
$rsrec = mysqli_fetch_array($selqueemp);

include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>

<div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            <div class="templatemo_post">
                                     
				</div>
 
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Employee Details</h1>
                    </div>
                    <div class="templatemo_post_mid">
<form method="post" action="" enctype="multipart/form-data" name="formempprofile" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION[setid]; ?>" >
<table width="531" height="567" border="1">
<?php
if($resi == 1)
{
?>
	<tr>
  		<td colspan="3" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
?>
<tr>
  <td><table width="531" height="567" border="1">
    <tr></tr>
    <tr>
      <td width="212" height="32">Branch Name</td>
      <td width="303">
<?php
$sqlbrqueryempb = "SELECT * FROM branches where branch_id='$rsrec[branch_id]'";
$selqueempb = mysqli_query($dbconn, $sqlbrqueryempb);
$rsrecb = mysqli_fetch_array($selqueempb);
echo "<strong>Branch name:</strong> ".$rsrecb[branch_name] . 
 " <br> <strong>Address</strong> - ". $rsrecb[address] . 
 " <br><strong>City:</strong> " . $rsrecb[city].
  " <br> <strong>State: </strong> - ". $rsrecb[state] .
    " <br> <strong>Counter: </strong> - ". $rsrecb[country];
?>
</td>
    </tr>
    <tr>
      <td height="36">Designation</td>
      <td>
        <?php
$sqlbrqueryd = "SELECT * FROM designation where desig_id='$rsrec[desig_id]'";
$selqued = mysqli_query($dbconn, $sqlbrqueryd);
$rsrecd = mysqli_fetch_array($selqued);
echo $rsrecd[desig_type];
?>
  </td>
    </tr>
    <tr>
      <td height="36"> First Name</td>
      <td><input type="text" name="fname" size="25" value="<?php echo $rsrec[emp_fname] ; ?>" /></td>
    </tr>
    <tr>
      <td height="34">Last Name</td>
      <td><input name="lname" type="text" id="lname" size="25"  value="<?php echo $rsrec[emp_lname] ; ?>" /></td>
    </tr>
    <tr>
      <td height="34">Profile Picture</td>
      <td><input type="file" name="profilepic" />
      <input type="hidden" name="hiddenprofilepic"  value="<?php echo $rsrec[profilepic] ; ?>"  />
<img alt="Blog" src="<?php 
if($rsrecemp[profilepic] != "")
{
echo "files/".$rsrecemp[profilepic];
}
else
{
echo "images/employee.png";
}
?>"  width="200" height="200"/>
      </td>
    </tr>
    <tr>
      <td height="36">Date Of Join</td>
      <td><?php echo $rsrec[doj] ; ?></td>
    </tr>
    <tr>
      <td height="41">Date of Birth</td>
      <td><?php echo $rsrec[dob] ; ?></td>
    </tr>
    <tr>
      <td height="35">Email Id</td>
      <td><input type="text" name="email" size="30"  value="<?php echo $rsrec[email_id] ; ?>" /></td>
    </tr>
    <tr>
      <td height="42">Contact No</td>
      <td><input type="text" name="cno" size="30"  value="<?php echo $rsrec[contact_no] ; ?>" /></td>
    </tr>
    <tr>
      <td height="37">Gender</td>
      <td><?php echo $rsrec[gender] ; ?></td>
    </tr>
    <tr>
      <td height="38">Login Id</td>
      <td><input type="text" name="logid" size="30"  value="<?php echo $rsrec[login_id] ; ?>" /></td>
    </tr>
    <tr>
      <td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit" /></td>
    </tr>
  </table></td></tr>
</table>
</form>

    <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->

			  </div>
              
		              
              <!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formempprofile.fname.value=="")
	{
		alert("Enter your First Name.....!!!");
		return false;
	}
	else if(document.formempprofile.lname.value=="")
	{
		alert("Enter your Last Name.....!!!");
		return false;
	}
	else if(document.formempprofile.email.value=="")
	{
		alert("Please enter your Email ID...!!!");
		return false;
	}
	else if(document.formempprofile.cno.value=="")
	{
		alert("Please enter your Contact details..!!!");
		return false;
	}
	else if(document.formempprofile.logid.value=="")
	{
		alert("Enter your login ID...!!!");
		return false;
	}
	
	else
	{
		return true;
	}
}
</script>