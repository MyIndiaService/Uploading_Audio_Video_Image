<?php
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
include("connectiondb.php");
?>    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            <div class="templatemo_post">
                      
                
                   			<div id="templatemo_search_box">
                              <form action="filemanager.php" method="get">
                               		  <h1> &nbsp; <font color="#FFFFFF">Search files</font> <input name="search" type="text" id="textfield" value=""/>
                                    <input type="submit" name="Submit" value="Search" alt="Submit" id="button" title="Submit" /></h1> 
                                </form>
                			</div>                  
				</div>
<?php
if(isset($_GET['shared']))
{
	$sqlfile = "SELECT * FROM files where ftype_id = '0'";
}
else if(isset($_GET['Submit']))
{
	$sqlfile = "SELECT * FROM  `files` WHERE  `filename` LIKE  '%$_GET[search]%' OR  `filedescription` LIKE  '%$_GET[search]%' OR  `filepath` LIKE  '%$_GET[search]%'";	
}
else
{
	$sqlfile = "SELECT * FROM files";
}
$qsqlfile = mysqli_query($dbconn, $sqlfile);
while($rssqlfile = mysqli_fetch_array($qsqlfile))
{
	$filetype = returnMIMEType($rssqlfile['filepath']);
	
	$sqlfiletype = "SELECT * FROM filetypes where file_extension='$filetype'";
	$qsqlfiletype = mysqli_query($dbconn, $sqlfiletype);
	$rssqlfiletype = mysqli_fetch_array($qsqlfiletype);
	
	
?>
              <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1><?php echo $rssqlfile['filename']; ?>
                        <a href='filesshared.php?shareid=<?php echo $rssqlfile['file_id']; ?>' style="float:right;">Share This file </a></h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	                        
                        <p><a href='files/<?php echo $rssqlfile['filepath']; ?>' target="_blank"></a>
                        <a href='files/<?php echo $rssqlfile['filepath']; ?>' target="_blank">

					<?php
                  	if($rssqlfiletype['file_path'] != "" )
                   	{
					?>
                        <img alt="Blog" src="files/<?php echo $rssqlfiletype['file_path']; ?>" width="140" height="140" />
                     <?php
                   }
                   else
                   {
					?>  
                    	<img alt="Blog" src="files/21543unknown.jpg" width="140" height="140" />
                     <?php
				   }
				   ?> 
                        </a><?php echo $rssqlfile['filedescription']; ?>
                   <br /><a href='files/<?php echo $rssqlfile['filepath']; ?>' target="_blank">
                  	
                   <img alt="Blog" src="images/animated-download-button.gif" width="230" height="65" /> 
                   </a>
                      </p> 
                      <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	<span class="post">Posted By: <?php echo $rssqlfile['sender_type']; ?></span>
                        <span class="post">Permission: <?php echo $rssqlfile['permission']; ?></span>
                        <span class="post">Date: <?php echo $rssqlfile['uploaded_at']; ?></span>
                    </div>
                    
				</div><!-- end of templatemo_post-->
<?php
}
?>
              <!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
<?php
include("rightsidebar.php");
?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
       <?php
			include("footer.php");
			?>