<?php
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<?php
include("connectiondb.php");
 
$createddate = date("Y-m-d");

if($_SESSION[setid] == $_POST[setid])
{
	if(isset($_POST["submit"]))
	{
if(isset($_GET[brid]))
{
	$sqlupdquery = "UPDATE branches set branch_name='$_POST[bname]',address='$_POST[txtadd]',city='$_POST[city]',state='$_POST[state]',country='$_POST[country]',contact_no='$_POST[cno]',email_id='$_POST[email]',status='$_POST[status]' where branch_id='$_POST[brid]'";
	$selque = mysqli_query($dbconn, $sqlupdquery);
	if(!$selque)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$resupd =  "<br><font color='green'><h1>Branch record updated successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}
else
{
		$sqlquery = "INSERT INTO branches (branch_name,address,city,state,country,contact_no,email_id,status) VALUES ('$_POST[bname]', '$_POST[txtadd]','$_POST[city]','$_POST[state]','$_POST[country]','$_POST[cno]','$_POST[email]','$_POST[status]')";
		$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Record inserted successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}
	}
}

if(isset($_GET[brid]))
{
	$sqlquery = "DELETE FROM branches where branch_id='$_GET[brid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Branch record Deleted successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}



$sqlselquery = "SELECT * FROM branches where branch_id='$_GET[editid]'";
$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);


$_SESSION[setid] = rand();

?>

    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section"><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View Notification	</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                    <table width="548" border="1">
  <tr>
     <th width="231" scope="col">&nbsp;Sender Details</th>
    <th width="135" scope="col">&nbsp;Subject</th>
    <th width="160" scope="col">&nbsp;Date Time</th>
   </tr>
  <?php
  $sql = "select * from notification where emp_id2='0'";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <tr>
			<td>&nbsp;";
		if($rs[emp_id1] == 0)
		{
			echo "Administrator";
		}
		echo "</td>
			<td>&nbsp; $rs[subject]</td>
		  	<td>&nbsp; $rs[mdate_time]</td>
	  </tr>";
	}
  ?>
</table>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>