<?php
$resupd="";
$rest="";
session_start(); // Developed by www.freestudentprojects.com
include("connectiondb.php");
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>

<?php
  
if(isset($_POST['setid']) && $_SESSION['setid'] == $_POST['setid'])
{
	
	if(isset($_POST["submit"]))
	{

if($_POST['desgid']>=1)
{

	$sqlupdquery = "UPDATE designation set desig_type='$_POST[desgtype]',comments='$_POST[txtd]',status='$_POST[status]' where desig_id='$_POST[desgid]'";
	$selque = mysqli_query($dbconn, $sqlupdquery);
	if(!$selque)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$resupd =  "<br><font color='green'><h1>Designation record updated successfully...</h1><br>
			<h2><a href='desig.php'>Click here to Update more Records..</a></h2>
			</font>";
		}
}
else
{		
		$sqlquery = "INSERT INTO designation (desig_type,comments,status) VALUES ('$_POST[desgtype]', '$_POST[txtd]','$_POST[status]')";
		$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Record inserted successfully...</h1><br>
			<h2><a href='desig.php'>Click here to add more..</a></h2>
			</font>";
			$rest = 1;
		}
	}
}
}

if(isset($_GET['delid']))
{
	$sqlquery = "DELETE FROM designation where desig_id='$_GET[delid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Designation Deleted successfully...</h1><br>
			<h2><a href='desig.php'>Click here to Delete more Records..</a></h2>
			</font>";
			$rest = 2;
		}
}

$sqlselquery = "SELECT * FROM designation where desig_id='$_GET[editid]'";
$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);

$_SESSION['setid'] = rand();

?>

 <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            	
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Designation</h1>
                      
                        
                    </div>
                    <div class="templatemo_post_mid">
 <?php
		if(strlen($resupd) == 152)
		{
			echo "<p align='center'>".$resupd."</p>";
		}
?>                    
<form method="post" action="" name="formdesig" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION['setid']; ?>" >
<input type="hidden" name="desgid" value="<?php echo $mssql['desig_id']; ?>" >
<table width="470" align="center" >
<?php
if($rest == 1 || $rest==2)
{
?>
	<tr>
  		<td colspan="2" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
else
{
?>
<tr>
<td width="143" height="39">Designation Type</td>
<td width="315"><input name="desgtype" type="text" size="35"  value="<?php echo $mssql['desig_type'];?>" /></td>
</tr>
<tr><td height="50">Description</td>
<td><textarea name="txtd" rows="3" cols="27"><?php echo $mssql['comments'];?></textarea></td></tr>
<tr><td height="45">Status</td>
<td>
<?php
$arr = array("Select","Enabled","Disabled");
?>
<select name="status">
<?php
foreach($arr as $value)
{
	if($value == $mssql[status])
	{
	echo "<option value='$value' selected>$value</option>";
	}
	else
	{
	echo "<option value='$value'>$value</option>";
	}
}
?>
</select>
</td></tr>
<tr><td height="54" colspan="2" align="center"><input class="fsSubmitButton" type="submit" name="submit"></td></tr>
<?php
}
?>
</table>
</form>
<div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View Designation</h1>
                    </div>
                    <div class="templatemo_post_mid">
                      <table width="548" border="1">
  <tr>
    <th width="153" scope="col">&nbsp;Designation type</th>
    <th width="189" scope="col">&nbsp;Description</th>
    <th width="86" scope="col">&nbsp;Status</th>
    <th width="92" scope="col">&nbsp;Action</th>
  </tr>
  <?php
  $sql = "select * from designation";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <tr>
		<td>&nbsp;$rs[desig_type]</td>
		<td>&nbsp;$rs[comments] </td>
		<td>&nbsp;$rs[status]</td>
		<td>
		<a href='desig.php?delid=$rs[desig_id]' onclick='return ConfirmDelete()'>Delete</a><br>
		<a href='desig.php?editid=$rs[desig_id]'>Edit</a>
		</td>
	  </tr>";
	}
  ?>
</table>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>

<script type="application/javascript">
function validation()
{
	if(document.formdesig.desgtype.value=="")
	{
		alert("Select Designation Type")
        document.formdesig.desgtype.focus();
		return false;
	}
	else if(document.formdesig.desgtype.value.length <2)
	{
		alert("Minum two characters required for Designation type")
        document.formdesig.desgtype.focus();
		return false;
	}
	else if(document.formdesig.desgtype.value.length >20)
	{
		alert("Designation type should not be exceed more than 20 characters")
        document.formdesig.desgtype.focus();
		return false;
	}
	else if(document.formdesig.txtd.value=="")
	{
		alert("Enter Description")
		document.formdesig.txtd.focus();
		return false;
	}
	else if(document.formdesig.status.value=="Select")
	{
		alert("Enter status")
		document.formdesig.status.focus();
		return false;
	}	
	else
	{
		return true;
	}
}
</script>