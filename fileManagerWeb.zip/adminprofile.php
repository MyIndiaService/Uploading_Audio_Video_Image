<?php
$msgi="";
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<?php
include("connectiondb.php");
 
$createddate = date("Y-m-d");

if(isset($_POST['setid']) && $_SESSION['setid'] == $_POST['setid'])
{
	if(isset($_POST["submit"]))
	{
		if(isset($_SESSION['admin_id']))
		{
			$sqlupdquery = "UPDATE administrator set admin_type='$_POST[adtype]',admin_name='$_POST[adname]',login_id='$_POST[log]',password='$_POST[pass]',email_id='$_POST[email]',
			created_date='$createddate',status='$_POST[status]' where  admin_id='$_SESSION[admin_id]'";		
		}
		else
		{
			$sqlupdquery = "UPDATE administrator set admin_type='$_POST[adtype]',admin_name='$_POST[adname]',login_id='$_POST[log]',password='$_POST[pass]',email_id='$_POST[email]',
			created_date='$createddate',status='$_POST[status]' where  admin_id='$_GET[editid]'";			
		}
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(mysqli_affected_rows($dbconn) ==1)
			{
				$msgi=2;
				$msg =  "<br><font color='green'><h1>Admin record updated successfully...</h1><br>
				<h2><a href='admin.php?editid=$_GET[editid]'>Click here to Edit..</a></h2>
				</font>";
			}
			else
			{
				$msg =  "<br>Problem in SQL insert query". mysqli_error($dbconn);
			}
	}
}

if(isset($_GET['adid']))
{
	$sqlselquery = "SELECT * FROM administrator where admin_id='$_GET[admin_id]'";
	$sqlquery = "DELETE FROM administrator where admin_id='$_GET[adid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$msg =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$msg =  "<br><font color='green'><h1>Administrator record Deleted successfully...</h1><br>
			<h2><a href='admin.php'>Click here to add more..</a></h2>
			</font>";
		}
}

  		$_SESSION['setid'] = rand();

		$sqlselquery = "SELECT * FROM administrator where admin_id='$_SESSION[admin_id]'";	
		$selque = mysqli_query($dbconn, $sqlselquery);
		$mssql = mysqli_fetch_array($selque);

?>

    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Admin Details</h1>
                    </div>
                    <div class="templatemo_post_mid">                 

<form method="post" name="formadmindetails" action="" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION['setid']; ?>" >
<table width="372" height="281" align="center" >
		<?php
        if($msgi == 1)
        {
        ?>
<tr>
<td colspan="2" align="center"><strong>&nbsp;<?php echo $msg; ?></strong></td>
</tr>
		<?php
        }
        else if($msgi == 2)
        {
        ?>
<tr>
<td colspan="2" align="center"><strong>&nbsp;<?php echo $msg; ?></strong></td>
</tr>
		<?php
        }
        else
        {
        ?>
	<tr>
	<td width="127" align=""><strong>Admin Type</strong></td>
	<td width="233">
            <select name="adtype">
            <?php
			$arr = array("Select","Super Admin","Admin");
            foreach($arr as $value)
            {
                if($value == $mssql[admin_type])
                {
                echo "<option value='$value' selected>$value</option>";
                }
                else
                {
                echo "<option value='$value'>$value</option>";
                }
            }
            ?>
            </select>
    </td>
	</tr>
	<tr>
<td><strong> Admin Full Name</strong></td>
<td><input type="text" name="adname" size="30" value="<?php echo $mssql['admin_name'];?>"></td></tr>
<tr>
  <td><strong>Admin Login ID</strong></td>
<td><input type="text" name="log" size="30" value="<?php echo $mssql['login_id'];?>"></td></tr>
<tr>
  <td><strong>New Password</strong></td>
<td><input type="password" name="pass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>
<tr>
  <td><strong>Confirm Password</strong></td>
<td><input type="password" name="cpass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>
	<tr>
  <td><strong>Email Id</strong></td>
<td><input type="text" name="email" size="30" value="<?php echo $mssql['email_id'];?>"></td></tr>
<tr>
  <td><strong>Account Status</strong></td>
<td>
<select name="status">
<?php
	$arr = array("Select","Enabled","Disabled");
	foreach($arr as $value)
	{
		if($value == $mssql['status'])
		{
		echo "<option value='$value' selected>$value</option>";
		}
		else
		{
		echo "<option value='$value'>$value</option>";
		}
	}
?>
</select>
</td></tr>
<tr><td align="center" colspan="2">
<input class="fsSubmitButton" type="submit" name="submit"></td></tr>

<?php
}
?>
</table>
</form>                
<div class="clear"></div>

</div>
<div class="templatemo_post_bottom">
                
</div>

</div>
<!-- end of templatemo_post-->

</div><!-- end of left section-->

<?php
include("rightsidebar.php");
?>

</div><!-- end of container-->
</div><!-- end of background middle-->

<?php
include("footer.php");
?>
<script type="application/javascript">
function validation()
{
	if(document.formadmindetails.adtype.value=="Select")
	{
		alert("Select Admin Type.....!!!");
		document.formadmindetails.adtype.focus();
		return false;
	}
	else if(document.formadmindetails.adname.value=="")
	{
		alert("Enter Admin Name....!!!");
		document.formadmindetails.adname.focus();
		return false;
	}
	else if(document.formadmindetails.adname.value.length <2)
	{
		alert("Minum two characters required for Admin Name")
        document.formadmindetails.adname.focus();
		return false;
	}
	else if(document.formadmindetails.adname.value.length >20)
	{
		alert("Admin Name should not be exceed more than 20 characters")
        document.formadmindetails.adname.focus();
		return false;
	}
	else if(document.formadmindetails.log.value != "admin")
	{
		if(document.formadmindetails.log.value=="")
		{
			alert("Enter Login ID...!!!");
			document.formadmindetails.log.focus();
			return false;
		}
			else if(document.formadmindetails.log.value.length <6)
		{
			alert("Minum 6 characters required for Admin Login ID")
			document.formadmindetails.log.focus();
			return false;
		}
		else if(document.formadmindetails.log.value.length >25)
		{
			alert("Admin Name should not be exceed more than 20 characters")
			document.formadmindetails.log.focus();
			return false;
		}
		else if(document.formadmindetails.pass.value=="")
		{
			alert("Enter Password...!!!");
			document.formadmindetails.pass.focus();
			return false;
		}
		
			else if(document.formadmindetails.pass.value.length <6)
		{
			alert("Minum 6 characters required for Password")
			document.formadmindetails.pass.focus();
			return false;
		}
		else if(document.formadmindetails.pass.value.length >12)
		{
			alert("Password should not be exceed more than 12 characters")
			document.formadmindetails.pass.focus();
			return false;
		}
		else if(document.formadmindetails.cpass.value=="")
		{
			alert("Please Confirm your Password...!!!");
			document.formadmindetails.cpass.focus();
			return false;
		}
		
		else if(document.formadmindetails.cpass.value.length <6)
		{
			alert("Minum 6 characters required for Confirm Password")
			document.formadmindetails.cpass.focus();
			return false;
		}
		else if(document.formadmindetails.cpass.value.length >12)
		{
			alert("Confirm Password should not be exceed more than 12 characters")
			document.formadmindetails.cpass.focus();
			return false;
		}
		else if(document.formadmindetails.pass.value != document.formadmindetails.cpass.value)
		{
			alert("Password and confirm password not matching..!!!");
			document.formadmindetails.cpass.focus();
			return false;
		}
		else if(document.formadmindetails.email.value=="")
		{
			alert("Please enter your Email ID...!!!");
			document.formadmindetails.email.focus();
			return false;
		}
		else if(document.formadmindetails.email.value.length <6)
		{
			alert("Minum 6 characters required for Email")
			document.formadmindetails.email.focus();
			return false;
		}
		else if(document.formadmindetails.email.value.length >12)
		{
			alert("Email should not be exceed more than 12 characters")
			document.formadmindetails.email.focus();
			return false;
		}
		else if(document.formadmindetails.status.value=="Select")
		{
			alert("Select status...!!!");
			document.formadmindetails.status.focus();
			return false;
		}
		else
		{
			return true;
		}
	}
	else
	{
		return true;
	}
}
</script>