<?php
$resi="";
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<?php
include("connectiondb.php");
 
$createddate = date("Y-m-d");

if(isset($_POST['setid']) && $_SESSION['setid'] == $_POST['setid'])
{
	if(isset($_POST["submit"]))
	{

			$sqlupdquery = "UPDATE administrator set password='$_POST[npass]' where login_id='$_POST[log]' and admin_type='$_POST[adtype]' AND password='$_POST[opass]'";
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(mysqli_affected_rows($selque) == 0)
			{
				$res =  "<br><font color='green'><h1>Old password is not valid...</h2></font>";
				$resi=2;
			}
			else
			{
				$res =  "<br><font color='green'><h1>Admin record updated successfully...</h1><br>
				<h2><a href='changepassword.php'>Click here to Edit..</a></h2>
				</font>";
				$resi=2;
			}
	}
}

if(isset($_GET['adid']))
{
	$sqlselquery = "SELECT * FROM administrator where admin_id='$_GET[admin_id]'";
	$sqlquery = "DELETE FROM administrator where admin_id='$_GET[adid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Administrator record Deleted successfully...</h1><br>
			<h2><a href='admin.php'>Click here to add more..</a></h2>
			</font>";
			$resi=1;
		}
}

$_SESSION['setid'] = rand();

$sqlselquery = "SELECT * FROM administrator where admin_id='$_GET[editid]'";
$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);
?>

    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
        	  <div class="templatemo_post">
                
               	  <div class="templatemo_post_top">
                    	<h1>Change password</h1>
                    </div>
                    <div class="templatemo_post_mid">                 

<form method="post" action="" name="formChangepass" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION['setid']; ?>" >
<table width="372" height="281" align="center" >
<?php
if($resi == 1)
{
?>
	<tr>
  		<td colspan="3" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
else if($resi == 2)
{
?>
	<tr>
  		<td colspan="3" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
else
{
?>
	<tr>
	<td width="127" align=""><strong><label> Admin Type</label></strong></td>
	<td width="233" colspan="2">
		<?php
        $arr = array("Select","Super Admin","Admin");
        ?>
            <select name="adtype">
            <?php
            foreach($arr as $value)
            {
                if($value == $mssql[admin_type])
                {
                echo "<option value='$value' selected>$value</option>";
                }
                else
                {
                echo "<option value='$value'>$value</option>";
                }
            }
            ?>
            </select>
    </td>
	</tr>
<tr>
  <td><strong>Admin Login ID</strong></td>
<td colspan="2"><input type="text" name="log" size="30" value="<?php echo $mssql['login_id'];?>"></td></tr>
<tr>
<td><strong>Old Password</strong></td>
<td colspan="2"><input type="password" name="opass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>
  <tr>
    <td><strong>New Password</strong></td>
<td colspan="2"><input type="password" name="npass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>
<tr>
  <td><strong>Confirm Password</strong></td>
<td colspan="2"><input type="password" name="cpass" size="30" value="<?php echo $mssql['password'];?>"></td></tr>

<tr><td colspan="2" align="center"><input class="fsSubmitButton" type="submit" name="submit"></td>
  <td align="center"><input type="reset" class="fsResetButton"/></td>
<td align="center" colspan="2">&nbsp;</td></tr>

<?php
}
?>
</table>
</form>
                
                      <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
              
              <!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formChangepass.adtype.value=="Select")
	{
		alert("Select Admin Type")
		document.formChangepass.adtype.focus();
		return false;
	}
	else if(document.formChangepass.log.value=="")
	{
		alert("Enter Admin Login ID")
		document.formChangepass.log.focus();
		return false;
	}
	else if(document.formChangepass.log.value.length >25)
	{
		alert("Admin Login ID should not be exceed more than 25 characters")
        document.formChangepass.log.focus();
		return false;
	}
		else if(document.formChangepass.opass.value=="")
		{
		alert("Enter Old Password")
		document.formChangepass.opass.focus();
		return false;
	}

	else if(document.formChangepass.npass.value=="")
	{
		alert("Enter New Password")
		document.formChangepass.npass.focus();
		return false;
	}
	else if(document.formChangepass.npass.value.length >12)
	{
		alert("New Password should not be exceed more than 12 characters")
		 document.formChangepass.npass.focus();
		return false;
	}
	else if(document.formChangepass.cpass.value=="")
	{
		alert("Please Confirm your Password")
		document.formChangepass.cpass.focus();
		return false;
	}
	else if(document.formChangepass.npass.value != document.formChangepass.cpass.value)
	{
		alert("New Password and Confirm password not matching..!!!");
		return false;
	}
		else if(document.formChangepass.cpass.value.length <6)
	{
		alert("Minum Six characters required for Confirm Password")
        document.formChangepass.cpass.focus();
		return false;
	}
	else if(document.formChangepass.cpass.value.length >12)
	{
		alert("Confirm Password should not be exceed more than 12 characters")
		 document.formChangepass.npass.focus();
		return false;
	}
	else
	{
		return true;
	}
}
</script>