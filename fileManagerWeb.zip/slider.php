	<link href="slider/css/styles.css" type="text/css" media="all" rel="stylesheet" />
	<!-- Skitter Styles -->
	<link href="slider/css/skitter.styles.css" type="text/css" media="all" rel="stylesheet" />
	<!-- Skitter JS -->
	<script type="text/javascript" language="javascript" src="slider/js/jquery-1.6.3.min.js"></script>
	<script type="text/javascript" language="javascript" src="slider/js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" language="javascript" src="slider/js/jquery.animate-colors-min.js"></script>
	<script type="text/javascript" language="javascript" src="slider/js/jquery.skitter.min.js"></script>
	<!-- Init Skitter -->
	<script type="text/javascript" language="javascript">
		$(document).ready(function() {
			$('.box_skitter_large').skitter({
				theme: 'clean',
				numbers_align: 'center',
				progressbar: true, 
				dots: true, 
				preview: true
			});
		});
	</script>
		<div>

				<div class="box_skitter box_skitter_large">
					<ul>
                    <li><a href="#cubeRandom"><img src="slider/images/example/24X7bank1.jpg" class="cubeRandom" /></a><div class="label_text">
                    <p> &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  24X7 bank Web File Manager</p></div></li>
						<li><a href="#cube"><img src="slider/images/example/24X7bank2.jpg" class="cube" height="350" width="950"/></a><div class="label_text"><p> &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  24X7 bank Web File Manager</p></div></li>
                        <li><a href="#cubeRandom"><img src="slider/images/example/24X7bank3.jpg" class="cubeRandom" /></a>
                        <div class="label_text"><p> &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  24X7 bank Web File Manager</p></div></li>	
                     
                        
                        
					</ul>
				</div>
			</div>
