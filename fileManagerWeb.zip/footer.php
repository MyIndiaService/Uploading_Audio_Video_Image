<div id="templatemo_bottom_panel">
    	<div id="templatemo_bottom_section">
              <div class="templatemo_bottom_section_box">
                    <div class="topsyndbankcopyright">
                        Copyright © Web File Management System | | Developed by <a href="http://www.myindiaservice.com">Freelance developer</a> Visit www.myindiaservice.com
                    </div>
                </div>
        </div>
</div>
    </body>
    </html>