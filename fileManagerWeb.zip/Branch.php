<?php
$resupd="";
$res="";
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<?php
include("connectiondb.php");
 
$createddate = date("Y-m-d");

if(isset($_POST['setid']) && $_SESSION['setid'] == $_POST['setid'])
{
	if(isset($_POST["submit"]))
	{
if(isset($_GET['brid']))
{
	$sqlupdquery = "UPDATE branches set branch_name='$_POST[bname]',address='$_POST[txtadd]',city='$_POST[city]',state='$_POST[state]',country='$_POST[country]',contact_no='$_POST[cno]',email_id='$_POST[email]',status='$_POST[status]' where branch_id='$_POST[brid]'";
	$selque = mysqli_query($dbconn, $sqlupdquery);
	if(!$selque)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$resupd =  "<br><font color='green'><h1>Branch record updated successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}
else
{
		$sqlquery = "INSERT INTO branches (branch_name,address,city,state,country,contact_no,email_id,status) VALUES ('$_POST[bname]', '$_POST[txtadd]','$_POST[city]','$_POST[state]','$_POST[country]','$_POST[cno]','$_POST[email]','$_POST[status]')";
		$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Record inserted successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}
	}
}

if(isset($_GET['brid']))
{
	$sqlquery = "DELETE FROM branches where branch_id='$_GET[brid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
			$res =  "<br><font color='green'><h1>Branch record Deleted successfully...</h1><br>
			<h2><a href='Branch.php'>Click here to add more..</a></h2>
			</font>";
		}
}



$sqlselquery = "SELECT * FROM branches where branch_id='$_GET[editid]'";
$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);


$_SESSION['setid'] = rand();

?>

    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
                        	
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Branch Details</h1>
                      
                        
                    </div>
                    <div class="templatemo_post_mid">
 <?php
						if(strlen($resupd) == 149)
						{
							echo "<p align='center'>".$resupd."</p>";
						}
?>
<form method="post" action="" name="formbranch" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION[setid]; ?>" >
<input type="hidden" name="brid" value="<?php echo $mssql[branch_id]; ?>" >
<table width="380" height="281" align="center" >
<?php
if(strlen($res) == 143)
{
?>
	<tr>
  		<td colspan="2" align="center"><strong>&nbsp;</strong> <?php echo $res; ?></td>
  	</tr>
<?php
}
else
{
?>
<td width="92"><strong>Branch</strong></td>
<td width="190"><input name="bname" type="text" id="bname" size="40" value="<?php echo $mssql['branch_name'];?>" />
</td>
</tr>
<tr>
<td valign="top"><strong>Address</strong></td>
<td><textarea name="txtadd" cols="35" rows="5"><?php echo $mssql['address'];?></textarea></td></tr>
<tr><td><strong>City</strong></td>
<td><input type="text" name="city" size="25" value="<?php echo $mssql['city'];?>"></td></tr>
<tr><td><strong>State</strong></td>
<td><input type="text" name="state" size="25" value="<?php echo $mssql['state'];?>"></td></tr>
<tr><td><strong>Country</strong></td>
<td><input type="text" name="country" value="<?php echo $mssql['country'];?>"></td></tr>
<tr><td><strong>Email Id</strong></td>
<td><input type="text" name="email" size="30" value="<?php echo $mssql['email_id'];?>"></td></tr>
<tr><td><strong>Contact No</strong></td>
<td><input type="text" name="cno" size="15" value="<?php echo $mssql['contact_no'];?>"></td></tr>
<tr><td><strong>Status</strong></td>
<td>
<?php
$arr = array("Select","Enabled","Disabled");
?>
<select name="status">
<?php
foreach($arr as $value)
{
	if($value == $mssql[status])
	{
	echo "<option value='$value' selected>$value</option>";
	}
	else
	{
	echo "<option value='$value'>$value</option>";
	}
}
?>
</select></td></tr>
 <tr>
 <td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit"></td>
 </tr>
<?php
}
?>
 </table>
</form>
 <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View Branch Record</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                    <table width="548" border="1" class="tftable" >
  <tr>
    <th width="181" scope="col">&nbsp;Branch Details</th>
    <th width="165" scope="col">&nbsp;Contact Details</th>
    <th width="60" scope="col">&nbsp;Status</th>
    <th width="60" scope="col">&nbsp;Action</th>
  </tr>
  <?php
  $sql = "select * from branches";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <tr>
		<td>&nbsp;Name:$rs[branch_name]</td>
		<td>&nbsp;Address: $rs[address] <br>
		    &nbsp;City: $rs[city] <br>
			&nbsp;State: $rs[state]<br>
			&nbsp;Country: $rs[country]
		 </td>
		<td>&nbsp;Contact No: $rs[contact_no] <br>
		    &nbsp;Email ID: <br>$rs[email_id] 
		</td>
		<td>&nbsp;$rs[status]<br>
		<a href='Branch.php?brid=$rs[branch_id]' onclick='return ConfirmDelete()'>Delete</a><br>
		<a href='Branch.php?editid=$rs[branch_id]'>Edit</a>
		</td>
	  </tr>";
	}
  ?>
</table>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formbranch.bname.value=="")
	{
		alert("Enter your Branch name")
		document.formbranch.bname.focus();
		return false;
	}
	else if(document.formbranch.bname.value.length <3)
	{
		alert("Minum three characters required for Branch Name")
        document.formbranch.bname.focus();
		return false;
	}
	else if(document.formbranch.bname.value.length >15)
	{
		alert("Branch Name should not be exceed more than 15 characters")
        document.formbranch.bname.focus();
		return false;
	}
	else if(document.formbranch.txtadd.value=="")
	{
		alert("Enter Address of the Branch")
		document.formbranch.txtadd.focus();
		return false;
	}
		else if(document.formbranch.txtadd.value.length <5)
	{
		alert("Minum Five characters required for Branch Address")
        document.formbranch.txtadd.focus();
		return false;
	}
	else if(document.formbranch.txtadd.value.length >30)
	{
		alert("Branch Address should not be exceed more than 30 characters")
        document.formbranch.txtadd.focus();
		return false;
	}
	else if(document.formbranch.city.value=="")
	{
		alert("Enter city")
		document.formbranch.city.focus();
		return false;
	}
			else if(document.formbranch.city.value.length <3)
	{
		alert("Minum Three characters required for Branch City")
        document.formbranch.city.focus();
		return false;
	}
	else if(document.formbranch.city.value.length >25)
	{
		alert("Branch City should not be exceed more than 25 characters")
        document.formbranch.city.focus();
		return false;
	}
	else if(document.formbranch.state.value=="")
	{
		alert("Enter State")
		document.formbranch.state.focus();
		return false;
	}
	
	else if(document.formbranch.state.value.length <3)
	{
		alert("Minum Three characters required for Branch state")
        document.formbranch.state.focus();
		return false;
	}
	else if(document.formbranch.state.value.length >25)
	{
		alert("Branch state should not be exceed more than 25 characters")
        document.formbranch.state.focus();
		return false;
	}
	else if(document.formbranch.country.value=="")
	{
		alert("Enter country")
		document.formbranch.country.focus();
		return false;
	}
	
	else if(document.formbranch.email.value=="")
	{
		alert("Please enter Email ID")
		document.formbranch.email.focus();
		return false;
	}
	
	else if(document.formbranch.email.value.length <6)
	{
		alert("Minum Six characters required for Email")
        document.formbranch.email.focus();
		return false;
	}
	else if(document.formbranch.email.value.length >25)
	{
		alert("Email should not be exceed more than 25 characters")
        document.formbranch.email.focus();
		return false;
	}
	else if(document.formbranch.cno.value=="")
	{
		alert("Enter contact details")
		document.formbranch.cno.focus();
		return false;
	}
	
	else if(document.formbranch.cno.value.length <6)
	{
		alert("Minum Six characters required for Contact No")
        document.formbranch.cno.focus();
		return false;
	}
	else if(document.formbranch.cno.value.length >25)
	{
		alert("Contact No should not be exceed more than 25 characters")
        document.formbranch.cno.focus();
		return false;
	}
	else if(isNaN(document.formbranch.cno.value))
	{
		alert("Please enter valid Contact Number")
		document.formbranch.cno.value = "";
        document.formbranch.cno.focus();
		return false;
	}	
		else if(document.formbranch.status.value=="Select")
	{
		alert("Select status")
		document.formbranch.status.focus();
		return false;
	}
	
	else
	{
		return true;
	}
}
</script>