<?php
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
include("connectiondb.php");
 
$createddate = date("Y-m-d");

if($_SESSION["logintype"] == "Admin")
{
$loginid = $_SESSION["admin_id"];
}
else
{
$loginid = $_SESSION["emp_id"];	
}

if($_SESSION[setid] == $_POST[setid])
{
	if(isset($_POST["submit"]))
	{
		if(isset($_GET[editid]))
		{
			$sqlupdquery = "UPDATE administrator set admin_type='$_POST[adtype]',admin_name='$_POST[adname]',login_id='$_POST[log]',password='$_POST[pass]',email_id='$_POST[email]',
			created_date='$createddate',status='$_POST[status]' where  admin_id='$_GET[editid]'";
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(!$selque)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
			}
			else
			{
				$res =  "<br><font color='green'><h1>Admin record updated successfully...</h1><br>
				<h2><a href=''admin.php?editid=$_GET[editid]'>Click here to Edit..</a></h2>
				</font>";
				$resi=2;
			}
		}
		else
		{
	$ftype = $_FILES["filepath"]["type"];
$sqlquery = "INSERT INTO files (sender_type,sender_id,filename,ftype_id,filepath,filedescription,permission,uploaded_at,status) VALUES ( '$_SESSION[logintype]','$loginid','$_POST[filename]','0','$_POST[filepath]','$_POST[filedescription]','$_POST[filepermission]','$createddate','$_POST[status]')";
			$insquery = mysqli_query($dbconn, $sqlquery);
			if(!$insquery)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
				$resi=1;
			}
			else
			{
				$res =  "<br><font color='green'><h1>File shared successfully...</h1><br>
				<h2><a href='filemanager.php'>Click here to add more..</a></h2>
				</font>";
				$resi=1;
			}
		}
		
	}
}

$_SESSION[setid] = rand();	

$sqlfile = "SELECT * FROM files where file_id='$_GET[shareid]'";
$qsqlfile = mysqli_query($dbconn, $sqlfile);
$rssqlfile = mysqli_fetch_array($qsqlfile);
?>
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
<?php
if($resi !=1)
{
?>
                    	<h1>Share this file</h1>
<?php
}
?>
                    </div>
                    <div class="templatemo_post_mid">
<script type="application/javascript">
function validate()
{
	if(document.frm6.filename.value="")
	{
		alert("Enter File name")
		return false;
	}
	else if(document.frm6.filedescription.value="")
	{
		alert("Enter file description")
		return false;
	}
	else if(document.frm6.filepath.value="")
	{
		alert("Enter Filepath")
		return false;
	}
	else if(document.frm6.filepermission.value="")
	{
		alert("Enter file Permission")
		return false;
	}
	else if(document.frm6.status.value="")
	{
		alert("Select status")
		return false;
	}	
	else
	{
		return true;
	}
}
</script>                  

<form method="post" action="" enctype="multipart/form-data" name="formfileshare" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION[setid]; ?>" >
<table  align="center">
<?php
if($resi ==1)
{
?>
<tr>
  <td colspan="2" align="center">&nbsp;<?php echo $res; ?></td>
</tr>
<?php
}
else
{
?>
<tr>
  <td>File Name</td>
  <td><input name="filename" type="text" id="filename" size="25" value="<?php echo $rssqlfile[filename]; ?>"></td></tr>
<tr><td>Description</td>
<td><textarea name="filedescription" id="filedescription" ><?php echo $rssqlfile[filedescription]; ?></textarea></td></tr>
<tr>
  <td>File path</td>
  <td><input name="filepath" type="text" id="filepath" size="25" value="<?php echo $rssqlfile[filepath]; ?>" readonly="readonly" /></td>
</tr>
<tr>
<td>Permission</td>
<td>
<select name="filepermission" id="filepermission">
<option value="">Select</option>
<option value="Locked">Locked</option>
<option value="All Employees">All Employees</option>
<option value="Branch Employees">Branch Employees</option>
</select>
</td>
</tr>

<tr><td>Status</td>
<td>
<select name="status">
<option>Select</option>
<?php
$arr = array("Enabled","Disabled");
foreach($arr as $value)
{
	if($value == $mssql[status])
	{
	echo "<option value='$value' selected>$value</option>";
	}
	else
	{
	echo "<option value='$value'>$value</option>";
	}
}
?>
</select>
</td></tr>
<tr><td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit"></td></tr>
<?php
}
?>
</table></form>
<div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post--><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formfileshare.filename.value=="")
	{
		alert("Enter File name")
		return false;
	}
	else if(document.formfileshare.filedescription.value=="")
	{
		alert("Enter file description")
		return false;
	}
	else if(document.formfileshare.filepath.value=="")
	{
		alert("Enter Filepath")
		return false;
	}
	else if(document.formfileshare.filepermission.value=="Select")
	{
		alert("Enter file Permission")
		return false;
	}
	else if(document.formfileshare.status.value=="Select")
	{
		alert("Select status")
		return false;
	}	
	else
	{
		return true;
	}
}
</script>   