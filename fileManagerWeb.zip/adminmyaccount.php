<?php
session_start(); // Developed by www.freestudentprojects.com
if(!isset($_SESSION["admin_id"]))
{
	header("Location: index.php");
}
include("header.php");
include("connectiondb.php");

$sqlbrqueryemp = "SELECT * FROM administrator where admin_id='$_SESSION[admin_id]'";
$selqueemp = mysqli_query($dbconn, $sqlbrqueryemp);
$rsrecemp = mysqli_fetch_array($selqueemp);
?>
    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            <div class="templatemo_post">
                      
                
                
				</div>
            	
                    <div class="templatemo_post">
                	<div class="templatemo_post_top">
					<br />
                        <h1 align="center" ><u>Administrator Dashboard</u></h1>
                    </div>
                    <div class="templatemo_post_mid">
                        <div class="clear"></div>
                    </div>
                    <div class="templatemo_post_bottom">
                    </div>
				</div><!-- end of templatemo_post-->
                
<div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Profile details</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                        <p><img alt="Blog" src="<?php 
						if($rsrecemp[profilepic] != "")
						{
						echo "files/".$rsrecemp[profilepic];
						}
						else
						{
						echo "images/admin.png";
						}
						?>"  width="200" height="200"/>
                        <strong>Name : </strong><?php echo $rsrecemp['admin_name'] ; ?><br />
                        <strong>Admin type. : </strong><?php echo $rsrecemp['admin_type']; ?><br />                        
                        <strong>Login ID : </strong><?php echo $rsrecemp['login_id']; ?><br />
                        <strong>Email ID : </strong><?php echo $rsrecemp['email_id']; ?><br />
                        <strong>Created date : </strong><?php echo $rsrecemp['created_date']; ?><br />
                        <strong>Last login : </strong><?php echo $rsrecemp['last_login']; ?><br />
<br />
                        </p>


						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">

                    </div>
                    
				</div>
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  administrator";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1>Number of Administrators: <?php echo mysqli_num_rows($qadmin); ?></h1>
                    </div>
                    <div class="templatemo_post_mid">


					
                        
                        <div class="clear"></div>
                        
                    </div>
                    
                    <div class="templatemo_post_bottom">
                    
                   
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
               <div class="templatemo_post">
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  employees";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1>Number of Employees: <?php echo mysqli_num_rows($qadmin); ?></h1>
                    </div>
                    <div class="templatemo_post_mid">
                        <div class="clear"></div>
                    </div>
                    <div class="templatemo_post_bottom">
                    </div>
				</div><!-- end of templatemo_post-->
                
                
                
               <div class="templatemo_post">
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  branches";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1>Number of Branches: <?php echo mysqli_num_rows($qadmin); ?></h1>
                    </div>
                    <div class="templatemo_post_mid">
                        <div class="clear"></div>
                    </div>
                    <div class="templatemo_post_bottom">
                    </div>
				</div><!-- end of templatemo_post-->
                
                
                
               <div class="templatemo_post">
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  files";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1>Number of Files Uploaded: <?php echo mysqli_num_rows($qadmin); ?></h1>
                    </div>
                    <div class="templatemo_post_mid">
                        <div class="clear"></div>
                    </div>
                    <div class="templatemo_post_bottom">
                    </div>
				</div><!-- end of templatemo_post-->
                
                
                
               <div class="templatemo_post">
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  filetypes";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1>Number of Supporting file extensions: <?php echo mysqli_num_rows($qadmin); ?></h1>
                    </div>
                    <div class="templatemo_post_mid">
                        <div class="clear"></div>
                    </div>
                    <div class="templatemo_post_bottom">
                    </div>
				</div><!-- end of templatemo_post-->

                               <div class="templatemo_post">
                	<div class="templatemo_post_top">
                    	<?php
							$sql = "SELECT * FROM  designation";
							$qadmin = mysqli_query($dbconn,$sql);
						?>
                        <h1>Number of Designation types: <?php echo mysqli_num_rows($qadmin); ?></h1>
                    </div>
                    <div class="templatemo_post_mid">
                        <div class="clear"></div>
                    </div>
                    <div class="templatemo_post_bottom">
                    </div>
				</div><!-- end of templatemo_post-->
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>