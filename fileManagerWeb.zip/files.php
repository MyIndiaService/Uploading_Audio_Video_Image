<?php
$resi="";
session_start(); // Developed by www.freestudentprojects.com
include("header.php");
include("connectiondb.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<?php
$createddate = date("Y-m-d");

if($_SESSION["logintype"] == "Admin")
{
$loginid = $_SESSION["admin_id"];
}
else
{
$loginid = $_SESSION["emp_id"];	
}

if(isset($_POST['setid']) && $_SESSION[setid] == $_POST[setid])
{
	if(isset($_POST["submit"]))
	{
		if(isset($_GET[editid]))
		{
			$sqlupdquery = "UPDATE files set filename='$_POST[filename]',filedescription='$_POST[filedescription]',permission='$_POST[filepermission]',uploaded_at='$createddate',status='$_POST[status]' where  file_id='$_GET[editid]'";
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(!$selque)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
			}
			else
			{
				$res =  "<br><font color='green'><h1>Files profile updated successfully...</h1><br>
				<h2><a href='files.php'>Click here to continue..</a></h2>
				</font>";
				$resi=2;
			}
		}
		else
		{

	$filename = rand().$_FILES["filepath"]["name"];	
	move_uploaded_file($_FILES["filepath"]["tmp_name"],"files/" . $filename);
	$ftype = $_FILES["filepath"]["type"];
$sqlquery = "INSERT INTO files (sender_type,sender_id,filename,ftype_id,filepath,filedescription,permission,uploaded_at,status) VALUES ( '$_SESSION[logintype]','$loginid','$_POST[filename]','$ftype','$filename','$_POST[filedescription]','$_POST[filepermission]','$createddate','$_POST[status]')";
			$insquery = mysqli_query($dbconn, $sqlquery);
			if(!$insquery)
			{
				$res =  "<br>Problem in SQL insert query". mysqli_error();
				$resi=1;
			}
			else
			{
				$res =  "<br><font color='green'><h1>Record inserted successfully...</h1><br>
				<h2><a href='files.php'>Click here to add more..</a></h2>
				</font>";
				$resi=1;
			}
		}
		
	}
}

if(isset($_GET['delid']))
{
	$sqlquery = "DELETE FROM files where file_id='$_GET[delid]'";
	$insquery = mysqli_query($dbconn, $sqlquery);
		if(!$insquery)
		{
			$res =  "<br>Problem in SQL insert query". mysqli_error();
		}
		else
		{
		?>
        <script type="application/javascript">
		alert("File deleted successfully..");
		</script>
        <?php
		}
}

$sqlselquery = "SELECT * FROM files where file_id='$_GET[editid]'";
$selque = mysqli_query($dbconn, $sqlselquery);
$mssql = mysqli_fetch_array($selque);

$_SESSION['setid'] = rand();		
?>
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>File Manager</h1>
                    </div>
                    <div class="templatemo_post_mid"><form method="post" action="" enctype="multipart/form-data" name="formfiles" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION[setid]; ?>" >
<table  align="center">
<?php
if($resi ==1)
{
?>
<tr>
  <td colspan="2" align="center">&nbsp;<?php echo $res; ?></td>
</tr>
<?php
}
else if($resi ==2)
{
?>
<tr>
  <td colspan="2" align="center">&nbsp;<?php echo $res; ?></td>
</tr>
<?php
}
else
{
?>
<tr>
  <td>File Name</td>
  <td><input name="filename" type="text" id="filename" size="25" value="<?php echo $mssql['filename']; ?>"></td></tr>
<tr><td>Description</td>
<td><textarea name="filedescription" id="filedescription" ><?php echo $mssql['filedescription']; ?></textarea></td></tr>
<tr>
  <td>File path</td>
  <td>
  <?php 
  if($mssql['filepath'] != "")
  {
  ?>
  <a href='files/<?php echo $mssql['filepath']; ?>' target="_blank">Download</a>
  <?php
  }
  else
  {
?>
  <input name="filepath" type="file" id="filepath" size="25" />
<?php
  }
  ?>
  </td>
</tr>
<tr>
<td>Permission</td>
<td>
<select name="filepermission" id="filepermission">
<?php
$arr = array("Select","Locked","All Employees","Branch Employees");
foreach($arr as $value)
{
	if($value ==$mssql[permission] )
	{
	echo "<option value='$value' selected>$value</option>";
	}
	else
	{
	echo "<option value='$value'>$value</option>";	
	}
}
?>
</select>
</td>
</tr>

<tr><td>Status</td>
<td>
<select name="status">
<option>Select</option>
<?php
$arr = array("Enabled","Disabled");
foreach($arr as $value)
{
	if($value == $mssql[status])
	{
	echo "<option value='$value' selected>$value</option>";
	}
	else
	{
	echo "<option value='$value'>$value</option>";
	}
}
?>
</select>
</td></tr>
<tr><td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit"></td></tr>
<?php
}
?>
</table></form>
<div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View Files</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                    <table width="548" border="1" class="tftable">
  <tr>
    <th width="181" scope="col">&nbsp;File Name</th>
    <th width="165" scope="col">&nbsp;Description</th>
    <th width="60" scope="col">&nbsp;Action</th>
     </tr>
  <?php
  $sql = "select * from files";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <tr>
		<td>&nbsp;$rs[filename]</td>
		<td>&nbsp;$rs[filedescription] <br><hr>
		    &nbsp;
		<a href='files/$rs[filepath]' target='_blank'><img src='images/download.png' width='168' height='57' /></a>
			
			</td>
			<td>&nbsp;$rs[status]<br>
		<a href='files.php?delid=$rs[file_id]' onclick='return ConfirmDelete()'>Delete</a><br>
		<a href='files.php?editid=$rs[file_id]'>Edit</a>
		</td>
	  </tr>";
	}
  ?>
                    </table>
                    
                    <table width="548" border="1">
                    </table>
      <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
	if(document.formfiles.filename.value=="")
	{
		alert("Enter File name")
		document.formfiles.filename.focus();
		return false;
	}
	else if(document.formfiles.filename.value.length <6)
	{
		alert("Minum 6 characters required for file name")
        document.formfiles.filename.focus();
		return false;
	}
	else if(document.formfiles.filename.value.length >25)
	{
		alert("File Name should not be exceed more than 20 characters")
        document.formfiles.filename.focus();
		return false;
	}
	else if(document.formfiles.filedescription.value=="")
	{
		alert("Enter file description")
		document.formfiles.filedescription.focus();
		return false;
	}
		else if(document.formfiles.filedescription.value.length <6)
	{
		alert("Minum 6 characters required for file description")
        document.formfiles.filedescription.focus();
		return false;
	}
	else if(document.formfiles.filedescription.value.length >25)
	{
		alert("File description should not be exceed more than 20 characters")
        document.formfiles.filedescription.focus();
		return false;
	}
	else if(document.formfiles.filepath.value=="")
	{
		alert("Enter Filepath")
		document.formfiles.filepath.focus();
		return false;
	}
	else if(document.formfiles.filepermission.value=="Select")
	{
		alert("Enter file Permission")
		document.formfiles.filepermission.focus();
		return false;
	}
	else if(document.formfiles.status.value=="")
	{
		alert("Select status")
		document.formfiles.status.focus();
		return false;
	}	
	else
	{
		return true;
	}
}
</script>   