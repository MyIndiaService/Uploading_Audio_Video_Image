<?php
session_start(); // Developed by www.freestudentprojects.com
include("connectiondb.php");
 
$sqlbrquery = "DELETE FROM employees where emp_id='$_GET[delid]'";
$selque = mysqli_query($dbconn, $sqlbrquery);

$createddate = date("Y-m-d");

if(isset($_POST['setid']) && $_SESSION['setid'] == $_POST['setid'])
{
	$filename = rand().$_FILES["profilepic"]["name"];	
	move_uploaded_file($_FILES["profilepic"]["tmp_name"],"files/" . $filename);

	if(isset($_POST["submit"]))
	{
		if(isset($_GET['brid']))
		{
			$sqlupdquery = "UPDATE employees set branch_name='$_POST[bname]',address='$_POST[txtadd]',city='$_POST[city]',state='$_POST[state]',country='$_POST[country]',contact_no='$_POST[cno]',email_id='$_POST[email]',status='$_POST[status]' where branch_id='$_POST[brid]'";
			$selque = mysqli_query($dbconn, $sqlupdquery);
			if(!$selque)
				{
					$res =  "<br>Problem in SQL insert query". mysqli_error();
				}
				else
				{
					$resupd =  "<br><font color='green'><h1>Branch record updated successfully...</h1><br>
					<h2><a href='Branch.php'>Click here to add more..</a></h2>
					</font>";
				}
		}
		else
		{
			$sqlquery = "INSERT INTO employees 
			(admin_id,branch_id,desig_id,emp_fname,emp_lname,profilepic,doj,dob,email_id,contact_no,gender,login_id,password,created_date,status) VALUES 
			('$_SESSION[admin_id]','$_POST[bname]','$_POST[desig]','$_POST[fname]','$_POST[lname]','$filename','$_POST[doj]','$_POST[dob]',
			'$_POST[email]','$_POST[cno]','$_POST[gender]','$_POST[logid]','$_POST[pass]','$createddate','$_POST[status]')";
				$insquery = mysqli_query($dbconn, $sqlquery);
				if(!$insquery)
				{
					echo $res =  "<br>Problem in SQL insert query". mysqli_error($dbconn);
				}
				else
				{
					$res =  "<br><font color='green'><h1>Record inserted successfully...</h1><br>
					<h2><a href='employee.php'>Click here to add more..</a></h2>
					</font>";
				}
		}
	}
}
	
$_SESSION['setid'] = rand();	

include("header.php");
?>
<script>
    function ConfirmDelete()
	{
		var result = confirm("Are you sure want to delete this?");
		if (result==true) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}
</script>
<div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Employee Details</h1>
                    </div>
                    <div class="templatemo_post_mid">
<form method="post" action="" enctype="multipart/form-data" name="formemp" onsubmit="return validation()">
<input type="hidden" name="setid" value="<?php echo $_SESSION[setid]; ?>" >
<table width="531" height="567" border="1">
<tr>
  <td><table width="531" height="567" border="1">
    <tr></tr>
    <tr>
      <td width="212" height="32">Branch Name</td>
      <td width="303"><select name="bname">
        <option value="Select">Select</option>
        <?php
$sqlbrquery = "SELECT * FROM branches where status='Enabled'";
$selque = mysqli_query($dbconn, $sqlbrquery);
while($rsrec = mysqli_fetch_array($selque))
{
echo "<option value='$rsrec[branch_id]'>Branch Name:$rsrec[branch_name]  | City: $rsrec[city]</option>";
}
?>
      </select></td>
    </tr>
    <tr>
      <td height="36">Designation</td>
      <td><select name="desig">
        <option value="Select">Select</option>
        <?php
$sqlbrquery = "SELECT * FROM designation where status='Enabled'";
$selque = mysqli_query($dbconn, $sqlbrquery);
while($rsrec = mysqli_fetch_array($selque))
{
echo "<option value='$rsrec[desig_id]'>$rsrec[desig_type]</option>";
}
?>
      </select></td>
    </tr>
    <tr>
      <td height="36"> First Name</td>
      <td><input type="text" name="fname" size="25" /></td>
    </tr>
    <tr>
      <td height="34">Last Name</td>
      <td><input name="lname" type="text" id="lname" size="25" /></td>
    </tr>
    <tr>
      <td height="34">Profile Picture</td>
      <td><input type="file" name="profilepic" /></td>
    </tr>
    <tr>
      <td height="36">Date Of Join</td>
      <td><input type="date" name="doj" /></td>
    </tr>
    <tr>
      <td height="41">Date of Birth</td>
      <td><input type="date" name="dob" /></td>
    </tr>
    <tr>
      <td height="35">Email Id</td>
      <td><input type="text" name="email" size="30" /></td>
    </tr>
    <tr>
      <td height="42">Contact No</td>
      <td><input type="text" name="cno" size="30" /></td>
    </tr>
    <tr>
      <td height="37">Gender</td>
      <td><input name="gender" type="radio" value="Male" checked="checked" />
        Male &nbsp;&nbsp;
        <input type="radio" name="gender" value="Female" />
        Female</td>
    </tr>
    <tr>
      <td height="38">Login Id</td>
      <td><input type="text" name="logid" size="30" /></td>
    </tr>
    <tr>
      <td height="38">Password</td>
      <td><input type="password" name="pass" size="30" /></td>
    </tr>
    <tr>
      <td height="39">Confirm Password</td>
      <td><input type="password" name="cpass" size="30" /></td>
    </tr>
    <tr>
      <td height="35">Status</td>
      <td><select name="status">
      <option value="Select">Select</option>
        <option value="Enabled">Enabled</option>
        <option value="Disabled">Disabled</option>
      </select></td>
    </tr>
    <tr>
      <td align="center" colspan="2"><input class="fsSubmitButton" type="submit" name="submit" /></td>
    </tr>
  </table></td></tr>
</table>
</form>

    <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	
                    </div>
                    
				</div><!-- end of templatemo_post-->
                  <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>View Administrator record</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	                 	

  <?php
  $sql = "select * from employees";
  $result = mysqli_query($dbconn,$sql);
	while($rs = mysqli_fetch_array($result))
	{	
	  echo "
	  <table width='548' border='1'>
  <tr>
    <th width='181' scope='col'>&nbsp;Employee Details</th>
    <th width='165' scope='col'>&nbsp;Contact Details</th>
    <th width='60' scope='col'>&nbsp;Action</th>
  </tr>
	  <tr>
	  <td>&nbsp;<img src='files/$rs[profilepic]' align='left'><br>
	  Name:$rs[emp_fname] $rs[emp_lname]<br>
	  Login ID: $rs[login_id]<br>
	  Email ID: <br>$rs[email_id]<br>
	  Gender: $rs[gender]<br>
	  Branch:$rs[branch_id]<br>
	  Designation:$rs[desig_id]<br>
		<td>&nbsp;Date of Join: $rs[doj] <br>
		&nbsp;Date of Birth: $rs[dob]</td>
		<td>&nbsp;$rs[status]<br>
		<a href='employee.php?delid=$rs[emp_id]' onclick='return ConfirmDelete()'>Delete</a><br>
		<a href='employee.php?editid=$rs[emp_id]'>Edit</a>
		</td>
	  </tr>
	  </table>
	  <hr>
	  ";
	}
  ?>
 <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                 
                    </div>
                    
			  </div>
              
		              
              <!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <?php
			include("rightsidebar.php");
			?>
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
    
    <?php
	include("footer.php");
		?>
<script type="application/javascript">
function validation()
{
var doj = new Date(document.formemp.doj.value); //Year, Month, Date 
var dob = new Date(document.formemp.dob.value); //Year, Month, Date	


	if(document.formemp.bname.value=="Select")
	{
		alert("Select your Branch Name")
		document.formemp.bname.focus();
		return false;
	}
	else if(document.formemp.desig.value=="Select")
	{
		alert("Enter Designation")
		document.formemp.desig.focus();
		return false;
	}
	else if(document.formemp.fname.value=="")
	{
		alert("Enter First Name")
		document.formemp.fname.focus();
		return false;
	}
	else if(document.formemp.fname.value=="")
	{
		alert("Please enter your Email ID...!!!");
		return false;
	}
		else if(document.formemp.fname.value.length <2)
	{
		alert("Minum 6 characters required for First Name")
        document.formemp.fname.focus();
		return false;
	}
	else if(document.formemp.fname.value.length >25)
	{
		alert("First Name should not be exceed more than 25 characters")
        document.formemp.fname.focus();
		return false;
	}
	else if(document.formemp.lname.value=="")
	{
		alert("Enter Last Name")
		document.formemp.lname.focus();
		return false;
	}
	
		else if(document.formemp.lname.value.length <2)
	{
		alert("Minum 6 characters required for Last Name")
        document.formemp.lname.focus();
		return false;
	}
	else if(document.formemp.lname.value.length >25)
	{
		alert("Last Name should not be exceed more than 25 characters")
        document.formemp.lname.focus();
		return false;
	}
	else if(document.formemp.profilepic.value=="")
	{
		alert("Profile Picture should be mandatory")
		document.formemp.profilepic.focus();
		return false;
	}
	else if(document.formemp.doj.value=="")
	{
		alert("Please enter Date of Join")
		document.formemp.doj.focus()
		return false;
	}
	else if(document.formemp.dob.value=="")
	{
		alert("Please Please enter Date of Birth")
		document.formemp.dob.focus()
		return false;
	}
	else if(dob > doj)
	{
		alert("Date of Birth is not valid ")
		document.formemp.dob.focus()
		return false;		
	}
	else if(document.formemp.email.value=="")
	{
		alert("Please enter your Email ID")
		document.formemp.email.focus()
		return false;
	}
	else if(document.formemp.email.value.length <6)
	{
		alert("Minum 6 characters required for Email")
        document.formemp.email.focus();
		return false;
	}
	else if(document.formemp.email.value.length >25)
	{
		alert("Email should not be exceed more than 25 characters")
        document.formemp.email.focus();
		return false;
	}
	else if(document.formemp.cno.value=="")
	{
		alert("Enter your Contact Details")
		document.formemp.cno.focus()
		return false;
	}
	else if(document.formemp.cno.value.length <6)
	{
		alert("Minum Six characters required for Contact No")
        document.formemp.cno.focus();
		return false;
	}
	else if(document.formemp.cno.value.length >25)
	{
		alert("Contact No should not be exceed more than 25 characters")
        document.formemp.cno.focus();
		return false;
	}
	else if(isNaN(document.formemp.cno.value))
	{
		alert("Please enter valid Contact Number")
		document.formemp.cno.value = "";
        document.formemp.cno.focus();
		return false;
	}
	else if(document.formemp.gender.value=="Male")
	{
		alert("Gender should be Entered")
		document.formemp.gender.focus()
		return false;
	}
	else if(document.formemp.logid.value=="")
	{
		alert("Enter your Login ID")
		document.formemp.logid.focus()
		return false;
	}
		else if(document.formemp.log.value.length <6)
	{
		alert("Minum 6 characters required for Employee Login ID")
        document.formemp.log.focus();
		return false;
	}
	else if(document.formemp.log.value.length >25)
	{
		alert("Employee Login ID should not be exceed more than 20 characters")
        document.formemp.log.focus();
		return false;
	}
	else if(document.formemp.pass.value=="")
		{
		alert("Enter your Password")
		document.formemp.pass.focus()
		return false;
	}
			else if(document.formemp.pass.value.length <6)
	{
		alert("Minum 6 characters required for Password")
        document.formemp.pass.focus();
		return false;
	}
	else if(document.formemp.pass.value.length >25)
	{
		alert("Password should not be exceed more than 20 characters")
        document.formemp.pass.focus();
		return false;
	}
	else if(document.formemp.cpass.value=="")
	{
		alert("Please Confirm your Password")
		document.formemp.cpass.focus()
		return false;
	}
				else if(document.formemp.cpass.value.length <6)
	{
		alert("Minum 6 characters required for Confirm Password")
        document.formemp.cpass.focus();
		return false;
	}
	else if(document.formemp.cpass.value.length >25)
	{
		alert("Confirm Password should not be exceed more than 20 characters")
        document.formemp.cpass.focus();
		return false;
	}
	else if(document.formemp.pass.value != document.formemp.cpass.value)
	{
		alert("Password and confirm password not matching..!!!");
		return false;
	}
	else if(document.formemp.status.value=="Select")
	{
		alert("Select status")
		document.formemp.status.focus()
		return false;
	}
	
	else
	{
		return true;
	}
}
</script>
