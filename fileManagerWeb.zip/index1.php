   <?php
			include("header.php");
			?>    
    <div id="templatemo_background_section_middle">
    
    	<div class="templatemo_container">
        
        	<div id="templatemo_left_section">
            
            <div class="templatemo_post">
                      
                
                   			<div id="templatemo_search_box">
                              <form action="#" method="post">
                               		  <h1> &nbsp; <font color="#FFFFFF">Search files</font> <input name="search" type="text" id="textfield" value=""/>
                                    <input type="submit" name="Submit" value="" alt="Submit" id="button" title="Submit" /></h1> 
                                </form>
                			</div>                  
				</div>
            	
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Blog Post Title 1 goes here</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	                        
                        <p><img alt="Blog" src="images/templatemo_055_blog.jpg" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nec dui. Donec nec neque ut quam sodales feugiat. Nam vehicula dapibus lectus. Integer imperdiet pretium dolor. Vivamus felis. Vivamus vulputate vehicula mi. Maecenas consectetur purus. </p>

						<p>Vestibulum id mi vitae nunc vulputate ullamcorper. Donec feugiat orci sed sapien. Fusce risus sem, egestas quis, imperdiet id, pellentesque vel, tortor. Fusce ante. Nunc at mi nec urna mollis ullamcorper. Nam aliquet, ligula in aliquet molestie, nunc arcu tristique nibh. </p>
                        
                        <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	<span class="post">Posted By: Admin</span>
                        <span class="post">Category: <a href="#">Web Design</a></span>
                        <span class="post">Date: 16:20, 19 October 2048</span>
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Blog Post Title 1 goes here</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	                        
                        <p><img alt="Blog" src="images/templatemo_055_blog.jpg" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nec dui. Donec nec neque ut quam sodales feugiat. Nam vehicula dapibus lectus. Integer imperdiet pretium dolor. Vivamus felis. Vivamus vulputate vehicula mi. Maecenas consectetur purus. </p>

						<p>Vestibulum id mi vitae nunc vulputate ullamcorper. Donec feugiat orci sed sapien. Fusce risus sem, egestas quis, imperdiet id, pellentesque vel, tortor. Fusce ante. Nunc at mi nec urna mollis ullamcorper. Nam aliquet, ligula in aliquet molestie, nunc arcu tristique nibh. </p>
                        
                        <div class="clear"></div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    
                    	<span class="post">Posted By: Admin</span>
                        <span class="post">Category: <a href="#">Web Design</a></span>
                        <span class="post">Date: 16:20, 19 October 2048</span>
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
                <div class="templatemo_post">
                
                	<div class="templatemo_post_top">
                    	<h1>Blog Post Title 2 goes here</h1>
                    </div>
                    <div class="templatemo_post_mid">
                    	
                        <p><img alt="Blog" src="images/templatemo_062_white.jpg" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nec dui. Donec nec neque ut quam sodales feugiat. Nam vehicula dapibus lectus. Integer imperdiet pretium dolor. Vivamus felis. Vivamus vulputate vehicula mi. Maecenas consectetur purus. </p>

						<p>Vestibulum id mi vitae nunc vulputate ullamcorper. Donec feugiat orci sed sapien. Fusce risus sem, egestas quis, imperdiet id, pellentesque vel, tortor. Fusce ante. Nunc at mi nec urna mollis ullamcorper. Nam aliquet, ligula in aliquet molestie, nunc arcu tristique nibh. </p>
						
                    
                        <div class="clear">             	        	
                        </div>
                        
                    </div>
                    <div class="templatemo_post_bottom">
                    	<span class="post">Posted By: Admin</span>
                        	<span class="post">Category: <a href="#">Script</a></span>
                        	<span class="post">Date: 18:24, 14 October 2048</span>
                    </div>
                    
				</div><!-- end of templatemo_post-->
                
            </div><!-- end of left section-->
            
            <div id="templatemo_right_section">
            	
                <div class="templatemo_section_box">
                	<div class="templatemo_section_box_top">
                    	<h1>Advertisements</h1>
                    </div>
					<div class="templatemo_section_box_mid">
                   		
						<a href="#"><img alt="125x125 Ad Banner"  src="images/templatemo_ads.jpg" /></a> 
                    	<a href="#"><img alt="125x125 Ad Banner"  src="images/templatemo_ads.jpg" /></a>
                    	<a href="#"><img alt="125x125 Ad Banner"  src="images/templatemo_ads.jpg" /></a>
                        <a href="#"><img alt="125x125 Ad Banner"  src="images/templatemo_ads.jpg" /></a>
                        
                      <div class="clear">&nbsp;</div>
					</div>
                  <div class="templatemo_section_box_bottom"></div>
                </div><!-- end of section box -->
                
                <div class="templatemo_section_box">
                	<div class="templatemo_section_box_top">
                    	<h1>About This Blog</h1>
                    </div>
					<div class="templatemo_section_box_mid">
                   		
						<p>This free  blog website layout is provided by <a href="http://www.templatemo.com" target="_parent">TemplateMo.com</a>. You may download, modify and apply this layout for any blog CMS websites.</p>
				  </div>
                    <div class="templatemo_section_box_bottom"></div>
                </div><!-- end of section box -->
                
                <div class="templatemo_section_box">
                	<div class="templatemo_section_box_top">
                    
                    	<h1>Categories</h1>
                        
                    </div>
					<div class="templatemo_section_box_mid">
                   		
						<ul>
                        	<li><a href="#">Web Design</a></li>
                            <li><a href="#">JavaScripts</a></li>
                            <li><a href="#">CSS Templates</a></li>
                            <li><a href="#">Flash Templates</a></li>
                        </ul>
					</div>
                    <div class="templatemo_section_box_bottom"></div>
                </div><!-- end of section box -->
                
            
            </div><!-- end of right Section -->
            
        </div><!-- end of container-->
	</div><!-- end of background middle-->
       <?php
			include("footer.php");
			?>