<?php
include("connectiondb.php");

$sqlft= "SELECT * FROM filetypes WHERE file_extension =  '$_GET[q]'";
$resultft = mysqli_query($dbconn,$sqlft) ;
$rsfiletype= mysqli_fetch_array($resultft);

?>]
<input type="hidden" name="setid" value="<?php echo $_SESSION['setid']; ?>" >
<table width="467" align="center" border="0"  >
  <tr>
    <td height="38"><strong>File Extension</strong></td>
    <td><input type="text" name="fileextension" value="<?php echo $_GET['q']; ?>" readonly></td>
  </tr>
<tr>
  <td width="106" height="42"><strong>File type</strong></td>
  <td width="306"><input name="filetype" type="text" id="filetype" size="45" value="<?php echo $rsfiletype['file_type']; ?>" /></td>
</tr>
<tr>
<td height="37"><strong>File Icon</strong></td>
<td>
<input type="file" name="file" id="file" />
<input type="hidden" name="hiddenfile" id="hiddenfile" value="<?php echo $rsfiletype['file_path']; ?>" />
<?php
if($rsfiletype['file_path'] == "")
{
	
}
else
{
	echo "<img src='files/$rsfiletype[file_path]'></img>";
}
?>
</td></tr>

<tr><td height="32" colspan="2" align="center"><input type="submit" name="submit" align="middle"></td></tr>

</table>